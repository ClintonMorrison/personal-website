This game was created by Clinton Morrison.

The music was taken from KeinzWeiter on FreeSound.org
http://www.freesound.org/people/keinzweiter/sounds/175626/

Note that the PHP backend of the game is not included so
the game cannot run properly.

All source code is contained in scipt.js. Documentation can be
found in the jsdoc folder.
