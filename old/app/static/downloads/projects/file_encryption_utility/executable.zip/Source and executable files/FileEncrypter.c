/*
 * File: FileEcnrypter.c
 *
 * Author: Clinton Morrison         Date: May 23, 2013
 *
 * This C program encrypts and decrypts files using a Vigen�re cipher
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define NAME_LENGTH 200
#define MAX_SIZE 5000
#define FILE_READ_ERROR -1

/*function prototypes*/
char getUserInput();
void getFilename(char *str);
int getFileContents(char *str1, char *str2);
int getKey();
void writeContentsToFile(char *strFilename, char *contents);
void encodeCaesarCipher(int key, char *contents);
void encodeVingenereCipher(char *key, char *contents);
void decodeVingenereCipher(char *key, char *contents);

/*main function*/
int main(void)
{
    /*Variables*/
    char currentMode = ' ';
    char filename[NAME_LENGTH];
    unsigned int filesize = 0;
    char *fileContents = malloc(MAX_SIZE * sizeof(char)); 
    char *password = malloc(NAME_LENGTH * sizeof(char));
    
    
    /*Continue running until user wants to quit*/
    while(currentMode != 'Q')
    {
        
        /*Determine what user wants to do*/
        printf("Enter 'E' to encrypt a file, 'D' to decode an encrypted file,\n or 'Q' to quit:  ");
        currentMode = getUserInput();
        printf("\n");
    
        /*If the user wants to encrypt a file*/
        if(currentMode == 'E')
        {
            getFilename(filename);
            
            /*Try to read contents of file*/
            if(getFileContents(filename, fileContents) != FILE_READ_ERROR)
            {
                printf("Enter the password: ");
                scanf("%s", password);
                encodeVingenereCipher(password, fileContents);
                writeContentsToFile(filename, fileContents);
                printf("The file has been encrypted.\n\n");
            }
            else /*Report error to user*/
            {
                printf("Error. The file could not be read.\n\n");
            }
        }
        /*If the user wants to decode an encrypted file*/
        else if (currentMode == 'D')
        {
            getFilename(filename);
            
            if(getFileContents(filename, fileContents) != FILE_READ_ERROR)
            {
                printf("Enter the password: ");
                scanf("%s", password);
                
                decodeVingenereCipher(password, fileContents);
                writeContentsToFile(filename, fileContents);
                printf("The file has been decoded.\n\n");
            }
            else /*Report error to user*/
            {
                printf("Error. The file could not be read.\n\n");
            }
        }
    }
    
    /*End program*/
    printf("\nProgram will now quit.\n");
    system("pause");
    return 0;
}



/*Gets either 'Y' or 'N' as input from user*/
char getUserInput()
{
    char c = ' ';
    
    scanf(" %c", &c);
    
    /*Ask user for input until it is given in proper format*/
    while(c != 'Q' && c != 'E' && c != 'D' && c != 'q' && c != 'e' && c != 'd')
    {
        printf("\nError. Enter Q, D or E:  ");
        scanf(" %c", &c);
    }
    
    /*Convert to upper case*/
    if(c == 'q')
        c = 'Q';
        
    if(c == 'e')
        c = 'E';
        
    if(c == 'd')
        c = 'D';
        
    return c;
}



/*Gets a filename from the user*/
void getFilename(char *str)
{
    printf("Enter a filename: ");
    scanf("%s", str);
}



/*Gets a encryption key from the user*/
int getKey()
{
    int key = 0;
    printf("Enter a key: ");
    scanf(" %d", &key);
    return key;
}

/*Gets the contents of an input file*/
int getFileContents(char *strFilename, char *strFileContents)
{
    /*open file for reading*/
    FILE *file = fopen(strFilename, "r");
    
    int index = 0;
    
    if(file != NULL)
    {
        while (1) 
        {
            char c = fgetc(file);
            
            if(c != EOF)
            {
                strFileContents[index] = c;
                index ++; 
            }
            else
            {
                break;
            }
        }
    }
    else
    {
        return -1;
    }
        
    
    /*close file*/
    fclose(file);
    return 0;
    
}
/*Writes contents into output file*/
void writeContentsToFile(char *strFilename, char *contents)
{
    FILE *file = fopen(strFilename, "w");
    fprintf(file, contents);
    fclose(file);
}

/*Apply Caesar cipher */
void encodeCaesarCipher(int key, char *contents)
{
    int i = 0;
    while(contents[i] != '\0')
    {
        contents[i] = contents[i] + key;
        i++;
    }
}

/*Applies Vingenere cipher*/
void encodeVingenereCipher(char *key, char *contents)
{
    int contents_index = 0;
    int key_index = 0;
    int shift = 0;
    
    while(contents[contents_index] != '\0')
    {
        if(key[key_index] != '\0')
        {
            shift = key[key_index];
            key_index ++;
        }
        else
        {
            key_index = 0;
            shift = key[key_index];
        }
        
        contents[contents_index] = contents[contents_index] + shift;
        contents_index++;
    }
}

/*Decodes Vingenere cipher*/
void decodeVingenereCipher(char *key, char *contents)
{
    int contents_index = 0;
    int key_index = 0;
    int shift = 0;
    
    while(contents[contents_index] != '\0')
    {
        if(key[key_index] != '\0')
        {
            shift = key[key_index];
            key_index ++;
        }
        else
        {
            key_index = 0;
            shift = key[key_index];
        }
        
        contents[contents_index] = contents[contents_index] - shift;
        contents_index++;
    }
}
