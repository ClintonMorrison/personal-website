Thanks for downloading one of my projects!


There is just one source file for this project called FileEncrypter.c.
To try out my program just run FileEcnrypter.exe and follow the instructions.

-Clinton Morrison