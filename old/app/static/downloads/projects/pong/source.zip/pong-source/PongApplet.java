//Author: Clinton Morrison, May, 2013
//Project: PONG APPLET GAME - Version 1.0

import java.applet.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

//This applet
public class PongApplet extends Applet implements Runnable, MouseListener {
	
   int width, height; //Width and height of applet
   int ticks = 0; //Update cycles elapsed
   GameManager game; //Manages game
   Image buffer; //Buffer image to render graphics to
   long last_system_millis=0;
   long timeBetweenUpdates = 10;
   Thread t1;
   boolean running; //Is the applet running?
   
   //Initialize applet
   public void init() {
	  this.setSize( 800, 400); //FOR TESTING ONLY. Ideal dimensions of applet
      width = getSize().width;
      height = getSize().height;
      setBackground( Color.black );
      game = new GameManager(new Dimension(width, height));
      running = true;
      //Create and start game loop thread
      t1 = new Thread(this);
      t1.start();
      
      addMouseListener(this); //Add mouse listener to applet
      
      last_system_millis = System.currentTimeMillis(); //Keep track of current system millis for reference
   }
 
   //Renders game to buffer image
   public void render()
   {
	   buffer = createImage(width, height);
	   if (buffer != null)
	   {
		   Graphics g = buffer.getGraphics();
		   buffer.getGraphics();	   
		   g.setColor(Color.BLACK);
		   g.fillRect(0, 0, width, height);
		   game.drawGame(g);
		   g.dispose();
	   }
	   
   }
   
   //Draws the game
   public void draw()
   {      
	   render(); //Render the game
	   Graphics g = this.getGraphics();
	   g.drawImage(buffer, 0, 0, null); //Draw buffered image
   }
  
   //Game loop in here
   public void run()
   {
	   while(running) //Game loop
	   {
		   gameLoop();
	   } 
   }
   
   
   //Loop which runs while game is running
   public void gameLoop()
   {
	   ticks++;
	   draw(); //Render and draw game to screen
	   game.updateGame(this.getMousePosition(), timeBetweenUpdates); //Update game state
	   
	   
	   //Sleep 
	   gameSleep();
   }
   
   public void gameSleep() //Causes thread to sleep (returns false if machine running too slow for ideal frame rate)
   {
	   if(last_system_millis == 0)
		   last_system_millis = System.currentTimeMillis();
	   
	   long time_taken = System.currentTimeMillis() -  last_system_millis;
	   
	   long sleep_time = timeBetweenUpdates - time_taken;
	   if(sleep_time > 0)
	   {
		   try 
		   { Thread.sleep(sleep_time);  } 
		   catch (InterruptedException e) { e.printStackTrace();}
	   }
	   
	   last_system_millis = System.currentTimeMillis(); 
   }
   
   //Called when applet closes
   public void stop()
   {
	   running = false;
	   game.stop();
   }

//Mouse click event
public void mouseClicked(MouseEvent arg0) {
	game.mouseClickInput(arg0.getPoint());
}

@Override
public void mouseEntered(MouseEvent arg0) {
	// TODO Auto-generated method stub
	
}

@Override
public void mouseExited(MouseEvent arg0) {
	// TODO Auto-generated method stub
	
}

@Override
public void mousePressed(MouseEvent arg0) {
	// TODO Auto-generated method stub
	
}

@Override
public void mouseReleased(MouseEvent arg0) {
	// TODO Auto-generated method stub
	
}
   
   
}