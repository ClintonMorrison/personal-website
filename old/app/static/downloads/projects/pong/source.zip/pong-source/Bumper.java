import java.awt.*;
import java.awt.geom.Point2D;

public class Bumper {

	//Attributes
	private Point p; //Coordinates of bumper
	private int length; //Length of bumper
	private int width; //Width of bumper
	private int max_y;
	private int score;
	
	//Constructor
	public Bumper(Point p, int length, int width, int max_y)
	{
		this.p = p;
		this.length = length;
		this.width = width;
		this.max_y = max_y;
		score = 0;
	}
	
	//Draws bumper
	public void drawBumper(Graphics g)
	{
		g.setColor(Color.WHITE);
		g.fillRect(p.x, p.y, width, length);
	}
	
	//Sets position of bumper
	public void setY(int y)
	{
		//Make sure to correct if out of bounds
		if(y < 0)
			y = 0;
		if(y + length > max_y)
		{
			y = max_y - length;
		}
		
		//If bounds are okay, set y
		p.y = y;
	}
	
	//Get score
	public int getScore()
	{
		return score;
	}
	
	//Gets position of bumper
	public Point getPosition()
	{
		return p;
	}
	
	//Moves middle to mouse
	public void moveMiddleToY(int y)
	{
		p.y = y - length/2; //Move middle of bumper to where mouse is
	}
	
	//Set score
	public void setScore(int s)
	{
		score = s;
	}
	
	//Gets height
	public int getLength()
	{
		return length;
	}
	
	//Gets width
	public int getWidth()
	{
		return width;
	}
	
	public boolean collidesWithBall(Ball b)
	{
		Rectangle bump = new Rectangle(p.x, p.y, width, length);
		Rectangle ball = new Rectangle((int)b.getPosition().x, (int)b.getPosition().y, b.getDiameter()/2, b.getDiameter()/2);
		return ball.intersects(bump);
	}
	
	//Increases score of player
	public void incrementScore()
	{
		score++;
	}
	
	//Resets score to 0
	public void resetScore()
	{
		score = 0;
	}
	
	//Slides the bumper a given amount up or down in the y direction
	public void slide(double y)
	{
		p.y += y;
	}
}
