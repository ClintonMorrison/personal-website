import java.awt.*;
import java.awt.geom.Point2D;
import java.util.Random;

public class Ball {
	
	//Attributes
	private Point2D.Double p; //Position vector
	private Point2D.Double v; //Velocity vector
	private int r; //Radius of ball
	
	//Constructor
	public Ball(Point2D.Double p, Point2D.Double v, int r)
	{
		this.p = p;
		this.v = v;
		this.r = r;
	}
	
	//Move ball
	public void update(long millisTaken)
	{
		p.x = (double) ((double)p.x + (double)v.x * (double)millisTaken);
		p.y = (float) ((double)p.y + (double)v.y * (double)millisTaken);
	}
	
	//Draw ball
	public void draw(Graphics g)
	{
		g.setColor(Color.WHITE);
		g.fillOval((int)p.x, (int)p.y, r, r);
	}
	
	//Sets position
	public void setPosition(Point2D.Double p)
	{
		this.p = p;
	}
	
	//Gets position of ball
	public Point2D.Double getPosition()
	{
		return p;
	}
	
	//Sets velocity
	public void setVelocity(Point2D.Double v)
	{
		this.v = v;
	}
	
	//Reverses direction
	public void reverseDirection()
	{
		v.x = -v.x;
		v.y = -v.y;
	}
	
	//Reverses x direction of motion
	public void reverseXDirection()
	{
		v.x = -v.x;
	}
	
	//Reverses x direction of motion
	public void reverseYDirection()
	{
		v.y = -v.y;
	}
		
	//Get the diameter (width) of ball
	public int getDiameter()
	{
		return 2*r;
	}
	
	public double getXVelocity()
	{
		return v.x;
	}
	
	//Randomizes direction of velocity, keeps magnitude constant
	public void changeDirection()
	{
		Random rand = new Random();	
		double mag = Math.sqrt(v.x*v.x + v.y*v.y);
		
		//Create random magnitudes between 0 and 1 for Vx and Vy
		v.y = rand.nextDouble();
		v.x = rand.nextDouble(); 
		
		//Make sure the x velocity is not too small (relative to y)
		if(v.y > v.x)
			v.x = v.y * 1.3;
		
		//Make sure the y velocity is not too small (relative to x)
		if(v.x > 3*v.y)
			v.x = v.x * 0.8;
		
		//Find a constant k to scale new v by to have previous magnitude (mag)
		double k = mag / Math.sqrt(v.x*v.x + v.y*v.y);
		
		//Scale the velocity vector by k
		v.x *= k; 
		v.y *= k;
		
		//Sometimes flip the y component of velocity, to add variety
		int invertY = rand.nextInt(2);
		if(invertY == 1)
			v.y *= -1;
		
	}
	
	//Moves ball in direction of velocity
	public void move()
	{
		p.x += v.x;
		p.y += v.y;
	}
}
