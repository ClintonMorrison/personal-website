import java.applet.AudioClip;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;


public class Button {
	
	//Attributes
	private Point p;
	private int width, height;
	private String text;
	private AudioClip select, click;
	private boolean mouseOver; //Is the mouse over the button?
	private boolean shown; //Should the button be displayed?
	private GameManager game;
	
	//Constructor
	public Button(GameManager game, String text, Point p, AudioClip select)
	{
		this.game = game;
		shown = true;
		this.text = text;
		this.p = p;
		this.select = select;
		height = 20;
		width = 6 + text.length()*10;
		mouseOver = false;
	}
	
	//Draws the button
	public void draw(Graphics g)
	{
		if(shown)
		{
			if(mouseOver)
				g.setColor(Color.MAGENTA);
			
			g.fill3DRect(p.x, p.y, width, height, true); //Draw outside of button
			g.setColor(Color.BLACK);
			g.fillRect(p.x+3, p.y+3, width-6, height-6); //Draw inside of button
			Font f; 
			f = new Font("Monospaced", 0, 15); //Create font
			g.setColor(Color.WHITE);
			g.setFont(f);
			g.drawString(text, p.x + 6,  p.y+(int)(height / 1.4));
		}
	}
	
	//Updates the button
	public void update(Point mouse_position)
	{
		if(shown)
		{
			Rectangle b = new Rectangle(p, new Dimension(width, height));
			if(!mouseOver && b.contains(mouse_position))
			{
				mouseOver = true;
				if(!game.getMuted())
					select.play();
			}
			else if(!b.contains(mouse_position))
			{
				mouseOver = false;
			}
		}
	}
	
	//Checks if point is on button
	public boolean contains(Point point)
	{
		if(!shown)
			return false;
		
		Rectangle b = new Rectangle(p, new Dimension(width, height));
		return b.contains(point);
	}
	
	//Hides button
	public void hide()
	{
		shown = false;
	}

	//Displays button
	public void show()
	{
		shown = true;
	}
	
	//Sets name of button
	public void setText(String t)
	{
		text = t;
		width = 6 + text.length()*10; //Change length
	}

}
