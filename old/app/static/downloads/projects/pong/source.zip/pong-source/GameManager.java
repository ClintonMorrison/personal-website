import java.applet.Applet;
import java.applet.AudioClip;
import java.awt.*;
import java.awt.geom.Point2D;
import java.awt.geom.Point2D.Double;
import java.net.MalformedURLException;
import java.net.URL;

//This class draws, updates, and manages all of the elements of the game
public class GameManager {
	
	//Attributes
	private Bumper p1, p2; //P1 is human player
	private Ball ball; //The ball
	private Dimension window; //bounds of game window
	private AudioClip bounce, music, lose, win, select, click;
	private Button button_menu;
	private boolean mainMenuOpen; //Is the main menu being displayed?
	private boolean muted;
	private MainMenu menu;
	private int difficulty; //Controls how difficult computer AI is (0 = easy, 1 = medium, 2 = hard)
	
	//Ai variables
	long timeSinceLastAIMove = 0; //Time since computer reconsidered direction it was moving in
	double computerSpeed = 7; //How quickly can the computer move?
	
	//Constructor
	public GameManager(Dimension window) 
	{
		difficulty = 0; //Default to easy difficulty
		mainMenuOpen = true; //Start game at main menu
		muted = false; //Start the game with sound on
		
		//Create bumpers and ball
		p1 = new Bumper(new Point(75, 50), 60, 9, 600);
		p2 = new Bumper(new Point(725, 50), 60, 9, 600);
		//V = 0.4, 0.3
		ball = new Ball(new Point2D.Double(150, 150), new Point2D.Double(0.4,0.3), 15);
		this.window = window; 
		
		//Load sounds
		bounce = Applet.newAudioClip(PongApplet.class.getResource("bounce.wav"));
		music = Applet.newAudioClip(PongApplet.class.getResource("music.wav"));
		lose = Applet.newAudioClip(PongApplet.class.getResource("damage.wav"));
		win = Applet.newAudioClip(PongApplet.class.getResource("win.wav"));
		select = Applet.newAudioClip(PongApplet.class.getResource("select.wav"));
		click = Applet.newAudioClip(PongApplet.class.getResource("click.wav"));
		
		//Create back to menu button for when in game
		button_menu = new Button(this, "Main Menu", new Point(375, 370), select);
		
		//Create main menu, this will be shown when applet starts
		menu = new MainMenu(this, window, select, click);
		
		//Loop music in main menu
		if(!muted)
			music.loop();
	}
	
	//Draws bumpers
	public void drawGame(Graphics g)
	{
		if(mainMenuOpen) //If main menu is open
		{
			menu.draw(g);
		}
		else //Otherwise draw game
		{
			p1.drawBumper(g);
			p2.drawBumper(g);
			ball.draw(g);
			drawScores(g);
			button_menu.draw(g);
		}
	}
	
	//Update game state
	public void updateGame(Point mouse_p, long millisTaken)
	{
		if (mainMenuOpen) //If main menu is open
		{
			if(mouse_p != null)
				menu.update(mouse_p);
		}
		else //Otherwise draw game
		{
			if(mouse_p != null) //If mouse is on screen
			{
				p1.moveMiddleToY(mouse_p.y);
				button_menu.update(mouse_p);
			}
			
			AiMove(millisTaken); //Move computer
			ball.update(millisTaken);
			dealWithCollisions();
		}
		
	}
	
	//Move the computer's bumper
	private void AiMove(long millisTaken)
	{
		int slide_dist = 0;
		
		//The computer can move faster for higher difficulties
		if(difficulty == 0)
			slide_dist = 1;
		
		if(difficulty == 1)
			slide_dist = 2;
		
		if(difficulty == 2)
			slide_dist = 3;
		
		timeSinceLastAIMove += millisTaken;
		
		//Only move the computer every 10 milliseconds
		if(timeSinceLastAIMove > 10 && ball.getXVelocity() > 0)
		{
			timeSinceLastAIMove -= 10;
			double ball_dist = p2.getPosition().y + p2.getLength()/2 - ball.getPosition().y;
			
			//Move the computer in the direction which will make it closer to the ball
			if(ball_dist < 0 && Math.abs(ball_dist) > 4*slide_dist)  //For when bumper is below ball [also only move if it is reasonably far away to prevent AI from "shaking" back in forth without moving]
				p2.slide(slide_dist); //The amount the computer slides is controlled by the difficulty level set by user
			else if(ball_dist > 0 && Math.abs(ball_dist) > 4*slide_dist)
				p2.slide(-slide_dist);
		}
	}
	
	//Called when applet is closed
	public void stop()
	{
		music.stop(); //Make sure music doesn't continue to play
	}
	
	//Correct any collisions
	private void dealWithCollisions()
	{
		if(p1.collidesWithBall(ball) || p2.collidesWithBall(ball) || ballCollidedWithSides())
		{
			ball.reverseXDirection(); //Reverse the direction of the ball
			
			//Move the ball (in the new direction) until the collision is avoided [this isn't needed if collided with sides since ball will be reset anyway]
			while(p1.collidesWithBall(ball) || p2.collidesWithBall(ball))
				ball.move();
			
			if(!muted)
				bounce.play();
			
			//If ball collided with sides, raise score of appropriate player
			if(ballCollidedWithSides())
			{
				if(ball.getPosition().x < 0)
					player2Score();
				else if(ball.getPosition().x > 0)
					player1Score();
			}
		}
		
		else if(ballCollidedWithTopOrBottom())
		{
			ball.reverseYDirection(); //Reverse direction of ball
			
			while(ballCollidedWithTopOrBottom()) //Move the ball in new direction until collision avoided
				ball.move();
			
			if(!muted)
				bounce.play();
		}
	}
	
	//Check if ball is collided with sides of window
	private boolean ballCollidedWithTopOrBottom()
	{
		Point2D.Double p = ball.getPosition();
		if(p.y < 0 || p.y + ball.getDiameter() > window.height)
		{	
			return true;
		}
			
		else
		{	
			return false;
		}
	}
	
	//Check if ball is collided with sides of window
	private boolean ballCollidedWithSides()
	{
		Point2D.Double p = ball.getPosition();
		if(p.x < 0 || p.x + ball.getDiameter() > window.width)
		{
			return true;
		}
			
		else
		{	
			return false;
		}
	}
	
	//Draws the score of players
	private void drawScores(Graphics g)
	{
		Font f = new Font("Monospaced", 0, 15);
		g.setFont(f);
		g.drawString("Player: " + p1.getScore(), p1.getPosition().x, 375);
		g.drawString("Computer: " + p2.getScore(), p2.getPosition().x - 50, 375);
	}
	
	//Resets ball to middle of board
	private void resetBall()
	{
		//Place ball in middle, and reverse it's direction
		ball.setPosition(new Point2D.Double(window.width/2.0, window.height/2.0));
		ball.reverseXDirection();
		ball.changeDirection();
	}
	
	//Gives player 1 point and resets ball
	private void player1Score()
	{
		p1.incrementScore();
		resetBall();
		if(!muted)
			win.play();
	}
	
	//Gives player 2 point and resets ball
	private void player2Score()
	{
		p2.incrementScore();
		resetBall();
		if(!muted)
			lose.play();
	}
	
	//Toggles if game is running or menu is open
	public void toggleMenu()
	{
		mainMenuOpen = ! mainMenuOpen;
		
		if(mainMenuOpen) //Reset score of both players if user just ended game
		{
			p1.resetScore();
			p2.resetScore();
		}
		
		if (mainMenuOpen && !muted)
			music.loop();
		else
			music.stop();
	}

	//Handles any mouse clicks
	public void mouseClickInput(Point click_p)
	{
		if(mainMenuOpen) //If the main menu is open
		{
			menu.mouseClickInput(click_p);
		}
		else //Otherwise if the game is running
		{
			if(button_menu.contains(click_p))
			{
				if(!muted)
					click.play();
				toggleMenu();
			}
		}
	}

	//Returns if game is muted
	public boolean getMuted()
	{
		return muted;
	}
	
	//Toggles if game is muted
	public void toggleMuted()
	{
		muted = ! muted;
		
		if(muted)
			music.stop();
		else
			music.loop();
	}
	
	//Toggles the difficulty of game
	public void toggleDifficulty()
	{
		difficulty ++; //Increase difficulty
		
		if(difficulty > 2) //Set it to 0 (easy) is above 2 (hard)
			difficulty = 0;
	}
	
	//Gets difficulty game is set at
	public String getDifficultyAsString()
	{
		if(difficulty == 0)
			return "easy";
		
		else if(difficulty == 1)
			return "medium";
		
		else
			return "hard";
	}
	
}
