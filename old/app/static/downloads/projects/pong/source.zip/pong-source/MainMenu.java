import java.applet.AudioClip;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Point;


public class MainMenu {
	
	//Attributes
	private String title;
	private Dimension window;
	private Button button_play; 
	private Button button_sound; 
	private Button button_difficulty;
	private Font f;
	private GameManager game;
	private AudioClip button_press;
	
	//Constructor
	public MainMenu(GameManager game, Dimension window, AudioClip button_select, AudioClip button_press)
	{
		this.game = game;
		this.window = window;
		f = new Font("Monospaced", 0, 40);
		title = "Pong";
		this.button_press = button_press;
		button_play = new Button(game, "Play", new Point(window.width/2 - 10, 150), button_select);
		button_difficulty = new Button(game, "Difficulty: easy", new Point(window.width/2 - 70, 250), button_select );
		button_sound = new Button(game, "Sound: on", new Point(window.width/2 - 30, 350), button_select );

	}
	
	//Draws the menu
	public void draw(Graphics g)
	{
		//Draw title
		g.setColor(Color.WHITE);
		g.setFont(f);
		g.drawString(title, window.width/2-30, 50);
		
		//Draw notes at bottom
		g.setFont( new Font("Monospaced", 2, 15));
		g.drawString("Developed by Clinton Morrison", window.width - 270, window.height - 5);
		g.drawString("Version 1.1", 5, window.height - 5);
		
		//Draw buttons
		button_play.draw(g);
		button_difficulty.draw(g);
		button_sound.draw(g);
	}
	
	//Updates main menu buttons
	public void update(Point mouse_position)
	{
		button_play.update(mouse_position); //Make buttons respond when mouse is hovered over them
		button_difficulty.update(mouse_position);
		button_sound.update(mouse_position);
	}
	
	//Handles input from mouse clicked event (to click buttons)
	public void mouseClickInput(Point p)
	{
		if (button_play.contains(p)) //If play button pushed
		{
			game.toggleMenu(); //Start game
			
			if(!game.getMuted())
				button_press.play(); //Play button press sound
		}
		
		if(button_sound.contains(p)) //If toggle sound button pushed
		{
			
			//Play click sound (if the game is muted or not)
			button_press.play();
			
			game.toggleMuted(); //Toggle if sound muted
			
			if(game.getMuted())
				button_sound.setText("Sound: off");
			
			if(!game.getMuted())
				button_sound.setText("Sound: on");
		}
		
		if(button_difficulty.contains(p)) //If toggle difficulty button is pushed
		{
			game.toggleDifficulty(); //Change difficulty 
			
			button_difficulty.setText("Difficulty: " + game.getDifficultyAsString());
			
			if(!game.getMuted()) //Play click sound if game not muted
				button_press.play();
		}
	}
}
