Hello!

Thanks for trying out my Password Manager program!
If you want to install the software, just run "setup.exe". 
You will need to have the .NET framework 4.5 installed. 

- Clinton Morrison