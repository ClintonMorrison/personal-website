import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.applet.*;
import java.net.*;

import javax.swing.*;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
public class MainGame extends JPanel 
{
	 public static SixDecks deck1 = new SixDecks();//create a SixDecks object
	 public static PlayerHand hand1 = new PlayerHand();//create a player hand object
	 public static PlayerHand hand2 = new PlayerHand();//create a 2nd one (for the dealer hand)
	 public static String records_file = "records.txt"; //the file that the records are stored in (for the PlayerRecords class)
	 public static PlayerRecord records = new PlayerRecord(records_file); //Create and load (if possible) player records

	
	public static void main(String[] args)
	{
		final SoundManager sounds = new SoundManager();
		
		deck1.shuffle();//shuffle the deck
		hand1.drawCards(deck1,2);
		hand2.drawCards(deck1,2);
		hand2.dealerHandIsNotExposed();//this method is used to set the first card of the dealer hand to isExposed = false (aka first card face down)
		
		//make one card not visible;
		//hand2.dealerHand();
		
		//create the player hand panel and hide it to start
		final PlayerHandPanel phandp = new PlayerHandPanel(hand1);
		phandp.setVisible(false);
		//declare dealer hand panel and hide it to start
		final DealerHandPanel dealerpanel = new DealerHandPanel(hand2);
		dealerpanel.setVisible(false);
		//hide the dealer score at first
		dealerpanel.hideValue();
		
		
		
		//create the two JButtons with the words "Draw" and "Hold" on them and new game
		final JButton drawButton = new JButton("Hit");
		final JButton holdButton = new JButton("Stand");
		final JButton newGameButton = new JButton("New Game");
		
		//create a button to show the player's statistics
		final JButton showStatisticsButton = new JButton("Show Statistics");
		
		//Create a button to toggle if the sound is muted
		final  JButton muteButton = new JButton("Mute");
		
		//lost and won, etc labels
		final JLabel welcome = new JLabel("Press \"New Game\" to play");
		final JLabel lost = new JLabel("You have lost");
		final JLabel won = new JLabel("You have won!");
		final JLabel push = new JLabel("Push! You get your bet back!");
		final JLabel blackjack = new JLabel("You got BlackJack!");
		final JLabel newGame = new JLabel("Will you \"Hit\" or \"Stand\"?");

		//center them
		welcome.setHorizontalAlignment(JLabel.CENTER);
		push.setHorizontalAlignment(JLabel.CENTER);
		won.setHorizontalAlignment(JLabel.CENTER);
		lost.setHorizontalAlignment(JLabel.CENTER);
		blackjack.setHorizontalAlignment(JLabel.CENTER);
		newGame.setHorizontalAlignment(JLabel.CENTER);

		
		//create a BlackjackGUI object
		final BlackjackGUI game1 = new BlackjackGUI(hand1, hand2);
		final ButtonPanel panel = new ButtonPanel();
		final JPanel topButtonPanel = new JPanel();
		final JPanel bottomButtonPanel = new JPanel();
		game1.addbuttons(panel);
		
		//add the two containers to the buttonpanel object
		panel.add(topButtonPanel);
		panel.add(bottomButtonPanel);
		
		//add the newGame button to the panel
		topButtonPanel.add(newGameButton);
		
		//add the welcome message
		game1.add(welcome, BorderLayout.NORTH);		
	
		//add the showStatistics button to the panel
		bottomButtonPanel.add(showStatisticsButton);
		
		//add the mute button to the panel
		bottomButtonPanel.add(muteButton);
		
		//the player hand handle added to the main GUI
		game1.add(phandp, BorderLayout.WEST);
		game1.add(dealerpanel,BorderLayout.EAST);
		//game1.add(message,BorderLayout.NORTH);
		

		
		sounds.playShuffleSound();	//Play Shuffle Sound
				
		//action listeners
		//Register Action Listeners with the buttons
		drawButton.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e) 
				{
					sounds.playDrawSound(); //Play draw sounds.
					hand1.drawCards(deck1);
					hand1.updateValue();
					phandp.updateCardDisplayPlayer(hand1);
					//System.out.println(hand1.getHandValue());
					if (hand1.getHandValue() > 21)
					{
						//if player gets abouve 21 tell them they have lost and remove buttons
						
						game1.remove(newGame);game1.add(lost,BorderLayout.NORTH);
						sounds.playLoseSound(); //Play losing sound.
						records.incrementLoses(); //Record as a loss in the records
						topButtonPanel.remove(drawButton);
						topButtonPanel.remove(holdButton);
						game1.Refresh();
					}					
				}
			}
		);
		
		//reset the decks and the hands 
		newGameButton.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e) 
				{
					//set the hand panels as visible
					phandp.setVisible(true);
					dealerpanel.setVisible(true);
					//reset the deck
					deck1 = new SixDecks();
					deck1.shuffle();//shuffle the deck
				
					//reset the player
					hand1 = new PlayerHand();
					hand1.drawCards(deck1,2);
					hand1.updateValue();
					phandp.updateCardDisplayPlayer(hand1);
					//System.out.println(hand1.getHandValue());
					
					//reset the dealer
					hand2 = new PlayerHand();
					hand2.drawCards(deck1,2);
					hand2.dealerHandIsNotExposed();
					hand2.updateValue();
					dealerpanel.updateCardDisplayDealer(hand2);
					//System.out.println(hand1.getHandValue());
					
					//remove the messages
					game1.remove(welcome);
					game1.remove(lost);
					game1.remove(push);
					game1.remove(won);
					game1.remove(blackjack);
					
					//add the correct message
					game1.add(newGame, BorderLayout.NORTH);
					
					//re add the buttons in the correct order
					topButtonPanel.remove(newGameButton);
					topButtonPanel.add(drawButton);
					topButtonPanel.add(holdButton);
					topButtonPanel.add(newGameButton);
					
					//Play Shuffle Sound
					sounds.playShuffleSound();
					
					//hide the dealer value again
					dealerpanel.hideValue();
					
					game1.Refresh();
					
					//if the player has BlackJack, and the dealer doesn NOT also have blackjack
					if(hand1.getHandValue()==21 && hand2.getHandValue()!=21)
					{
						sounds.playWinSound(); //Play the victory sound
						game1.add(blackjack, BorderLayout.NORTH);
						hand2.dealerHandIsExposed();
						dealerpanel.showValue();
						topButtonPanel.remove(drawButton);
						topButtonPanel.remove(holdButton);
						dealerpanel.updateCardDisplayDealer(hand2);
						game1.remove(newGame);
						records.incrementBlackjacks();
					}
					
					//if both the player and the dealer has blackjack
					if(hand1.getHandValue()==21 && hand2.getHandValue()==21)
					{
						sounds.playPushSound();
						game1.add(push, BorderLayout.NORTH);
						game1.remove(blackjack);
						records.incrementStandoffs(); //Count as standoff in records
						hand2.dealerHandIsExposed();
						dealerpanel.showValue();
						topButtonPanel.remove(drawButton);
						topButtonPanel.remove(holdButton);
						dealerpanel.updateCardDisplayDealer(hand2);
						game1.remove(newGame);
						
					}
					
					game1.Refresh();
				}
			}
		);
		
		//evaluate cards when hold is pressed
		holdButton.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e) 
				{
					hand2.dealerHandIsExposed();
					dealerpanel.showValue();
					topButtonPanel.remove(drawButton);
					topButtonPanel.remove(holdButton);
					//keeps track if the dealer lost
					boolean dlost = false;
					hand2.updateValue();
					dealerpanel.updateCardDisplayDealer(hand2);
					game1.Refresh();
					sounds.playDrawSound(); //Play draw sounds.
					//wait for half a second
					
					try
					{
						Thread.currentThread().sleep(500);//sleep for 500 ms
					}
					catch(InterruptedException ie)
					{
						System.exit(0); 
					}
					
					//dealer only will draw if hand is less than 17 (casino rules)
					while(hand2.getHandValue()<17)
					{
						hand2.drawCards(deck1);
						hand2.updateValue();
						dealerpanel.updateCardDisplayDealer(hand2);
						game1.Refresh();
						sounds.playDrawSound(); //Play draw sounds.
						try
						{
							Thread.currentThread().sleep(500);//sleep for 500 ms
						}
						catch(InterruptedException ie)
						{
							System.exit(0); 
						}
					}
				
					if(hand2.getHandValue()>21)
					{
						dlost = true;
						game1.remove(newGame);
						game1.add(won,BorderLayout.NORTH);
						sounds.playWinSound(); //Play the victory sound
						records.incrementWins(); //Count win in records
					}
				
					
					//if your hand value is more than the dealers you win
					if(hand1.getHandValue() > hand2.getHandValue() && dlost == false)
					{
						game1.remove(newGame);
						game1.add(won, BorderLayout.NORTH);
						sounds.playWinSound(); //Play the victory sound
						records.incrementWins(); //Count win in records
					}
					
					// if your hand value is greater than the dealers you lose
					if(hand2.getHandValue() > hand1.getHandValue() && dlost == false)
					{
						sounds.playLoseSound(); //Play the defeat sound
						records.incrementLoses(); //Record as a loss in the records
						game1.remove(newGame);
						game1.add(lost, BorderLayout.NORTH);
					}
					
					// if your hand value is the same as the dealers
					if(hand2.getHandValue() == hand1.getHandValue() && dlost == false)
					{
						sounds.playPushSound();//play the push sound
						records.incrementStandoffs(); //Count as a standoff
						game1.remove(newGame);
						game1.add(push, BorderLayout.NORTH);
					}

					game1.Refresh();
				}
			}
		);
		
		//add action listener for "show statistics" button
		showStatisticsButton.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e) 
				{
					records.displayGUI(game1);
					//StatisticsGUI stat_window = new StatisticsGUI(records); //Create seperate window to show records currently stored
				}
			}
		);
		
		//add action listener for "Mute" button
		muteButton.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e) 
				{
					sounds.toggleMute(); //Toogle is sounds are muted or not
				}
			}
		);


	
	//Add a shutdown hook to the window to make sure the records are saved before the window is closed
	Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
        public void run() 
		  {
            records.writeDataToFile(records_file); //Write the new data into the records file
        }
    }));
		
	}
}