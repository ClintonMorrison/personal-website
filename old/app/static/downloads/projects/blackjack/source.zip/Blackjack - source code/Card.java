/*Currently being created by Eric.
This class is to simulate a playing card.
This class has three instance variables, the suit(char), the card number(int), and the card picture(ImageIcon)
In addition to the instance variables, 52 static constant ImageIcons have been declared, along with 1 static constant array to store these ImageIcon
H1 = Ace of Hearts, D12 = Queen of Diamonds, etc
*/
import javax.swing.*;//to use ImageIcon class

public class Card
{
	private char suit;//D-diamond, H-heart, S-spade, C-club
	private int cardNum;//1->13: eg 1 = ace; 11, 12, 13 = jack, queen, king
	private ImageIcon pic;//to store the reference to the appropriate picture
	private boolean isExposed;//true if card is visible in the GUI, false if card is hidden - automatically set to true in constructor
	//create static constants imageIcon objects for every card in a 52 card deck (plus the back of the card)
	final static ImageIcon D1_PIC = new ImageIcon("CardImages/D1.png");
	final static ImageIcon D2_PIC = new ImageIcon("CardImages/D2.png");
	final static ImageIcon D3_PIC = new ImageIcon("CardImages/D3.png");
	final static ImageIcon D4_PIC = new ImageIcon("CardImages/D4.png");
	final static ImageIcon D5_PIC = new ImageIcon("CardImages/D5.png");
	final static ImageIcon D6_PIC = new ImageIcon("CardImages/D6.png");
	final static ImageIcon D7_PIC = new ImageIcon("CardImages/D7.png");
	final static ImageIcon D8_PIC = new ImageIcon("CardImages/D8.png");
	final static ImageIcon D9_PIC = new ImageIcon("CardImages/D9.png");
	final static ImageIcon D10_PIC = new ImageIcon("CardImages/D10.png");
	final static ImageIcon D11_PIC = new ImageIcon("CardImages/D11.png");
	final static ImageIcon D12_PIC = new ImageIcon("CardImages/D12.png");
	final static ImageIcon D13_PIC = new ImageIcon("CardImages/D13.png");
	final static ImageIcon H1_PIC = new ImageIcon("CardImages/H1.png");
	final static ImageIcon H2_PIC = new ImageIcon("CardImages/H2.png");
	final static ImageIcon H3_PIC = new ImageIcon("CardImages/H3.png");
	final static ImageIcon H4_PIC = new ImageIcon("CardImages/H4.png");
	final static ImageIcon H5_PIC = new ImageIcon("CardImages/H5.png");
	final static ImageIcon H6_PIC = new ImageIcon("CardImages/H6.png");
	final static ImageIcon H7_PIC = new ImageIcon("CardImages/H7.png");
	final static ImageIcon H8_PIC = new ImageIcon("CardImages/H8.png");
	final static ImageIcon H9_PIC = new ImageIcon("CardImages/H9.png");
	final static ImageIcon H10_PIC = new ImageIcon("CardImages/H10.png");
	final static ImageIcon H11_PIC = new ImageIcon("CardImages/H11.png");
	final static ImageIcon H12_PIC = new ImageIcon("CardImages/H12.png");
	final static ImageIcon H13_PIC = new ImageIcon("CardImages/H13.png");
	final static ImageIcon S1_PIC = new ImageIcon("CardImages/S1.png");
	final static ImageIcon S2_PIC = new ImageIcon("CardImages/S2.png");
	final static ImageIcon S3_PIC = new ImageIcon("CardImages/S3.png");
	final static ImageIcon S4_PIC = new ImageIcon("CardImages/S4.png");
	final static ImageIcon S5_PIC = new ImageIcon("CardImages/S5.png");
	final static ImageIcon S6_PIC = new ImageIcon("CardImages/S6.png");
	final static ImageIcon S7_PIC = new ImageIcon("CardImages/S7.png");
	final static ImageIcon S8_PIC = new ImageIcon("CardImages/S8.png");
	final static ImageIcon S9_PIC = new ImageIcon("CardImages/S9.png");
	final static ImageIcon S10_PIC = new ImageIcon("CardImages/S10.png");
	final static ImageIcon S11_PIC = new ImageIcon("CardImages/S11.png");
	final static ImageIcon S12_PIC = new ImageIcon("CardImages/S12.png");
	final static ImageIcon S13_PIC = new ImageIcon("CardImages/S13.png");
	final static ImageIcon C1_PIC = new ImageIcon("CardImages/C1.png");
	final static ImageIcon C2_PIC = new ImageIcon("CardImages/C2.png");
	final static ImageIcon C3_PIC = new ImageIcon("CardImages/C3.png");
	final static ImageIcon C4_PIC = new ImageIcon("CardImages/C4.png");
	final static ImageIcon C5_PIC = new ImageIcon("CardImages/C5.png");
	final static ImageIcon C6_PIC = new ImageIcon("CardImages/C6.png");
	final static ImageIcon C7_PIC = new ImageIcon("CardImages/C7.png");
	final static ImageIcon C8_PIC = new ImageIcon("CardImages/C8.png");
	final static ImageIcon C9_PIC = new ImageIcon("CardImages/C9.png");
	final static ImageIcon C10_PIC = new ImageIcon("CardImages/C10.png");
	final static ImageIcon C11_PIC = new ImageIcon("CardImages/C11.png");
	final static ImageIcon C12_PIC = new ImageIcon("CardImages/C12.png");
	final static ImageIcon C13_PIC = new ImageIcon("CardImages/C13.png");
	final static ImageIcon BACK_PIC = new ImageIcon("CardImages/Back.png");
	//create an Array which stores these ImageIcon objects (53 total objects - the first 52 correspond to the faces of the cards - the 53rd is the backside of the card)
	final static ImageIcon[] PIC_ARRAY = {D1_PIC, D2_PIC, D3_PIC, D4_PIC, D5_PIC, D6_PIC, D7_PIC, D8_PIC, D9_PIC, D10_PIC, D11_PIC, D12_PIC, D13_PIC,
		H1_PIC, H2_PIC, H3_PIC, H4_PIC, H5_PIC, H6_PIC, H7_PIC, H8_PIC, H9_PIC, H10_PIC, H11_PIC, H12_PIC, H13_PIC, S1_PIC, S2_PIC, S3_PIC, S4_PIC, S5_PIC, S6_PIC, 
		S7_PIC, S8_PIC, S9_PIC, S10_PIC, S11_PIC, S12_PIC, S13_PIC, C1_PIC, C2_PIC, C3_PIC, C4_PIC, C5_PIC, C6_PIC, C7_PIC, C8_PIC, C9_PIC, C10_PIC, C11_PIC, C12_PIC, 
		C13_PIC, BACK_PIC};
	
	//constructor
	public Card(char suit, int cardNum)
	{
		this.suit=suit;
		this.cardNum=cardNum;
		isExposed = true;//default is showing
		//if statements to determine which pic to attach to each card object
		if(suit == 'D')
			pic = PIC_ARRAY[cardNum-1];
		else if(suit == 'H')
			pic = PIC_ARRAY[13+cardNum-1];
		else if(suit == 'S')
			pic = PIC_ARRAY[26+cardNum-1];
		else if(suit == 'C')
			pic = PIC_ARRAY[39+cardNum-1];
	}
	//get/set methods
	public void setSuit(char suit)
	{
		this.suit=suit;
	}
	public void setCardNum(int cardNum)
	{
		this.cardNum=cardNum;
	}
	public void setPic(ImageIcon pic)
	{
		this.pic=pic;
	}
	public void setIsExposed(boolean isExposed)
	{
		this.isExposed=isExposed;
		
		if(isExposed)//if the card is exposed, determine which image it shows
		{
			if(suit == 'D')
				pic = PIC_ARRAY[cardNum-1];
			else if(suit == 'H')
				pic = PIC_ARRAY[13+cardNum-1];
			else if(suit == 'S')
				pic = PIC_ARRAY[26+cardNum-1];
			else if(suit == 'C')
				pic = PIC_ARRAY[39+cardNum-1];
		}
		else//if the card is not exposed, show the 53rd image (BACK_PIC.png)
		{
			pic = PIC_ARRAY[52];
		}
	}
	public char getSuit()
	{
		return suit;
	}
	public int getCardNum()
	{
		return cardNum;
	}
	public ImageIcon getPic()
	{
		return pic;
	}
	public boolean getIsExposed()
	{
		return isExposed;
	}
	
	public String toString()
	{
		return ""+suit+cardNum+" "+pic;
	}
}