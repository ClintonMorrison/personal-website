import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.applet.*;
import java.net.*;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class SoundEffectDemo extends JPanel 
{
	 public static Deck deck1 = new Deck();//create a deck object
	 public static PlayerHand hand1 = new PlayerHand();//create a player hand object
	 public static PlayerHand hand2 = new PlayerHand();//create a 2nd one (for the dealer hand)
	
	
	public static void main(String[] args)
	{
		final SoundManager sounds = new SoundManager();

		System.out.println(deck1);//print the deck
		deck1.shuffle();//shuffle the deck
		System.out.println(deck1);	//print the deck	
		deck1.shuffle();//shuffle the deck
		System.out.println(deck1);	//print the deck
		hand1.drawCards(deck1,2);
		hand2.drawCards(deck1,2);
		hand2.dealerHandIsNotExposed();//this method is used to set the first card of the dealer hand to isExposed = false (aka first card face down)
		
		//make one card no visible;
		//hand2.dealerHand();
		System.out.println(hand1);
		System.out.println(hand2);
		System.out.println(deck1);
		deck1.shuffle();
		System.out.println(deck1);
		
		//create the player hand panel and get the first value
		final PlayerHandPanel phandp = new PlayerHandPanel(hand1);
		//declare dealer hand panel
		final DealerHandPanel dealerpanel = new DealerHandPanel(hand2);
		
		
		
		//create the two JButtons with the words "Draw" and "Hold" on them and new game
		final JButton drawButton = new JButton("Draw");
		final JButton holdButton = new JButton("Hold");
		final JButton newGameButton = new JButton("New Game");
		
		
		//lost and won labels
		final JLabel lost = new JLabel("You have lost");
		final JLabel won = new JLabel("You have won!");
		final JLabel tie = new JLabel("This is a tie");

		final JLabel message = new JLabel("I Love you");

		//center them
		tie.setHorizontalAlignment(JLabel.CENTER);
		won.setHorizontalAlignment(JLabel.CENTER);
		lost.setHorizontalAlignment(JLabel.CENTER);
		message.setHorizontalAlignment(JLabel.CENTER);
		
	
		
		//the following commented code tests various aspects with regards to the various GUI classes
		//create a BlackjackGUI object
		final BlackjackGUI game1 = new BlackjackGUI(hand1, hand2);
		final ButtonPanel panel = new ButtonPanel();
		game1.addbuttons(panel);
		
		
		
		//add the buttons to the panel
		panel.add(drawButton);
		panel.add(holdButton);
		panel.add(newGameButton);
		
	
		
		//the player hand handle added to the main GUI
		game1.add(phandp, BorderLayout.WEST);
		game1.add(dealerpanel,BorderLayout.EAST);
		game1.add(message,BorderLayout.NORTH);
		

		
		
		//action listeners
		//Register Action Listeners with the buttons
		drawButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
						sounds.playDrawSound(); //Play draw sounds.
						
						hand1.drawCards(deck1);
						hand1.updateValue();
						phandp.updateCardDisplayPlayer(hand1);
						System.out.println(hand1.getHandValue());
						if (hand1.getHandValue() > 21){
							//if player gets abouve 21 tell them they have lost and remove buttons
							game1.add(lost,BorderLayout.CENTER);
							sounds.playLoseSound(); //Play losing sound.
							panel.remove(drawButton);
							panel.remove(holdButton);
							game1.Refresh();
							
							
							
						}
						
						}
					});
		
		//reset the decks and the hands 
		newGameButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				//reset the deck
				deck1 = new Deck();
				deck1.shuffle();//shuffle the deck
				
				//reset the player
				hand1 = new PlayerHand();
				hand1.drawCards(deck1,2);
				hand1.updateValue();
				phandp.updateCardDisplayPlayer(hand1);
				System.out.println(hand1.getHandValue());
				
				//reset the dealer
				hand2 = new PlayerHand();
				hand2.drawCards(deck1,2);
				hand2.dealerHandIsNotExposed();
				hand2.updateValue();
				dealerpanel.updateCardDisplayDealer(hand2);
				System.out.println(hand1.getHandValue());
				
				//remove the message
				game1.remove(lost);
				game1.remove(tie);
				game1.remove(won);
				
				//re add the buttons in the correct order
				panel.remove(newGameButton);
				panel.add(drawButton);
				panel.add(holdButton);
				panel.add(newGameButton);
				
				//Play Shuffle Sound
				sounds.playShuffleSound();
				
				game1.Refresh();
						}
					});
		
		//evaluate cards when hold is pressed
		holdButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				hand2.dealerHandIsExposed();
				panel.remove(drawButton);
				panel.remove(holdButton);
				//keeps track if the dealer lost
				boolean dlost = false;
				
				//dealer only will draw if hand is less than 17 (casino rules)
			while(hand2.getHandValue()<17){
				hand2.drawCards(deck1);
				hand2.updateValue();
				dealerpanel.updateCardDisplayDealer(hand2);
				game1.Refresh();
			}
			
			if(hand2.getHandValue()>21){
				dlost = true;
				game1.add(won);
				sounds.playWinSound(); //Play the victory sound
			}
			
				
			//if your hand value is more than the dealers you win
			if(hand1.getHandValue() > hand2.getHandValue() && dlost ==false){
				game1.add(won);
				sounds.playWinSound(); //Play the victory sound
			}
			
			// if your hand value is greater than the dealers you loose
			if(hand2.getHandValue() > hand1.getHandValue() && dlost ==false ){
				sounds.playLoseSound(); //Play the defeat sound
				game1.add(lost);
			}			
				game1.Refresh();
						}
					});
		

		
		
		
		
		
	}
	
	
}