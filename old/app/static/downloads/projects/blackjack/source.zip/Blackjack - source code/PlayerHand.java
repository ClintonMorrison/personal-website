/*Currently being created by Eric
This class will simulate a players hand
It will have an ArrayList<Card>, int handValue, boolean isSoft  as instance variables.
Class will have methods like draw and play
*/

import java.util.*;
public class PlayerHand
{
	private ArrayList<Card> myHand = new ArrayList<Card>();//arraylist that represents the hand
	private int handValue;//to hold the value of the hand
	private boolean isSoft;//associated with the value - true if an ace is being counted as 11 (without going over)
	//constructor (start the hand with no cards in it)
	public PlayerHand()
	{
	}
		
	//method to draw 'n' card from the top of the deck
	public void drawCards(SixDecks myDeck, int n)
	{
		for(int i = 0; i<n; i++)
		{
			if(myDeck.getCurrentDeck().isEmpty())
			{
				System.out.println("Error - There is no more deck left to draw from!");
			}
			else
			{	
				myHand.add(myDeck.getCurrentDeck().get(0));//add the top card to your hand
				myDeck.removeTopCard();//remove the top card from the deck 
				//Because the input parameter is simply a reference to the 
				//original ArrayList, this will remove the first item from the ArrayList representing the deck.
			}
		}
		updateValue(); //recalculate the value of the hand

	}
	//overloaded method.  Draw 1 card from top of the deck
	public void drawCards(SixDecks myDeck)
	{
		if(myDeck.getCurrentDeck().isEmpty())
		{
			System.out.println("Error - There is no more deck left to draw from!");
		}
		else
		{	
			myHand.add(myDeck.getCurrentDeck().get(0));//add the top card to your hand
			myDeck.removeTopCard();//remove the top card from the deck 
			//Because the input parameter is simply a reference to the 
			//original ArrayList, this will remove the first item from the ArrayList representing the deck.
		}
		updateValue(); //recalculate the value of the hand
	}
	//this method (re)calculates the value of the cards - to be called every time a card is added
	public void updateValue()
	{
	handValue = 0;//reset the hand value to zero and start counting again!
	isSoft = false;
		for(int i=0; i<myHand.size(); i++)//go through all the cards in the hand (that are exposed)
		{
			if(myHand.get(i).getIsExposed()==true)
			{
				if(myHand.get(i).getCardNum() == 1 && !isSoft)//if the card is an ace, add 11 to the total, mark the hand as soft
				{
					handValue+=11;
					isSoft=true;
				}
				else if(myHand.get(i).getCardNum()>=10)//if the card is a 10,J, Q, or K add 10 to the handValue
				{
					handValue+=10;
				}
				else
				{
					handValue+=myHand.get(i).getCardNum();
				}	
			}
			//check to see if over 21 and the hand is soft, in case the ace needs to be counted as a 1
			if(handValue>21 && isSoft==true)
			{
				handValue-=10;
				isSoft=false;
			}
		}
	}
	//get methods
	public int getHandValue()
	{
		return handValue;
	}
	public boolean getIsSoft()
	{
		return isSoft;
	}
	public ArrayList<Card> getMyHand()
	{
		return myHand;
	}
	
	//toString method
	public String toString()
	{
		return ""+myHand;
	}
	//sets the first card to not exposed
	public void dealerHandIsNotExposed()
	{
		myHand.get(0).setIsExposed(false);
		updateValue();
	}
	//sets the first card to be exposed again
	public void dealerHandIsExposed()
	{
		myHand.get(0).setIsExposed(true);
		updateValue();
	}
}