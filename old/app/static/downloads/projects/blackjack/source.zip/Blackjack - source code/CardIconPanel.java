import javax.swing.*;
import java.awt.*;

public class CardIconPanel extends JPanel
{
	private PlayerHand temp;//to hold the address of the PlayerHand to be displayed
	public CardIconPanel(PlayerHand h)
	{
		temp = h;
		setLayout(new GridLayout(0,3));//four 2 rows, 4 columns
		for(int i=0; i<temp.getMyHand().size();i++)
		{
			add(new JLabel(temp.getMyHand().get(i).getPic()));
			
		}		
	}
	
	//for when the draw card is pressed, needed the remove all otherwise same cards printed everytime
	public void updateCardPanel(PlayerHand h){
		this.removeAll();
		temp = h;
		setLayout(new GridLayout(0,3));//four 2 rows, 4 columns
		for(int i=0; i<temp.getMyHand().size();i++)
		{
			add(new JLabel(temp.getMyHand().get(i).getPic()));
			
		}	
		this.revalidate();
		this.repaint();
	}
	
	
	
}