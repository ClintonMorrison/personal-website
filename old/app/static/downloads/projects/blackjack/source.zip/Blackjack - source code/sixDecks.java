/*Currently being created by Eric
Plan is to have 52 Card objects.  In addition, have an ArrayList
that keeps track of the cards currently in the deck, and in what order.
I want to implement a "Shuffle" class, which will randomize all 52 cards 
in the ArrayList.  Certain accessor and mutator methods will be created as well
*/


//note, the deck is designed so that the top card of currentDeck arraylist is the 0th element
import java.util.*;
import javax.swing.*;
public class SixDecks
{
	Random rn = new Random();//create a random number generator
	//create an arraylist to hold the card objects currently in the deck in order
	private ArrayList<Card> currentDeck = new ArrayList<Card>(52);
	//constructor
	public SixDecks()
	{
		for(int j = 0; j<6; j++)
		{
			for(int i = 1; i<=13; i++)
			{	//add 13 diamond cards, 1->13
				currentDeck.add(new Card('D', i));
			}
			for(int i = 1; i<=13; i++)
			{	//add 13 Hearts cards, 1->13
				currentDeck.add(new Card('H', i));
			}
			for(int i = 1; i<=13; i++)
			{	//add 13 spades cards, 1->13
				currentDeck.add(new Card('S', i));
			}
			for(int i = 1; i<=13; i++)
			{	//add 13 clubs cards, 1->13
				currentDeck.add(new Card('C', i));
			}
		}
	}
	
	public void shuffle()//method to shuffle the deck
	{
		ArrayList<Card> tempCardList = new ArrayList<Card>(currentDeck.size());//create a temporary arraylist to hold card objects
		
		int tempInt = rn.nextInt(currentDeck.size());//create a temporary integer variable, and initialize with a random integer
		ArrayList<Integer> tempIntList = new ArrayList<Integer>(currentDeck.size());//create a temporary arrayList to hold the random integers
		
		for(int i = 0; i<currentDeck.size(); i++)//this for loop adds the integers from 1 to the size of the currentDeck, in random order to tempIntList
		{
			while(tempIntList.contains(tempInt))//if tempIntList already contains that particular random number, choose another random number
			{
				tempInt = rn.nextInt(currentDeck.size());
			}
			tempIntList.add(tempInt);
		}
		
		for(int i = 0; i<currentDeck.size(); i++)//this for loop sets the 'i'th element of the tempCardList to a random element from currentDeck
		{
			tempCardList.add(currentDeck.get(tempIntList.get(i)));
		}
		//now we must transfer each element back to the currentDeck
		//this for loop sets the 'i'th element of the currentDeck to the 'i'th element of tempCardList.
		for(int i = 0; i<currentDeck.size(); i++)
		{
			currentDeck.set(i, tempCardList.get(i));
		}
	}
	
	//get/set Methods **********Incomplete**************
	public ArrayList<Card> getCurrentDeck()
	{
		return currentDeck;
	}
	public void removeTopCard()
	{
		currentDeck.remove(0);
	}
	//toString method
	public String toString()
	{
		return ""+currentDeck;
	}
}