import javax.swing.*;//needed for Swing classes
import java.awt.*;//needed for BorderLayout classes
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


/*This class will define the game window (A class which extends the JFrame class).
This window frame will hold the 4 panels "PlayerHandPanel.java", "DealerHandPanel.java", 
"GameMessagesPanel.java", and "ButtonPanel.java".
*/



public class BlackjackGUI extends JFrame
{
	private final int WINDOW_WIDTH = 450;//this field defines the width in pixels of the game window
	private final int WINDOW_HEIGHT = 300;//this field defines the height in pixels of the game window
	private PlayerHand player, dealer;
	private PlayerHandPanel playerPanel;
	private DealerHandPanel dealerPanel;
	private ButtonPanel buttonPanel;
	//constructor
	public BlackjackGUI(PlayerHand player, PlayerHand dealer)
	{
		this.player=player;
		this.dealer=dealer;
		//set the title bar text
		setTitle("Blackjack");
		
		//set the size of the window
		setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
		
		//specify what happens when you click the close button
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//add a border layout manager
		setLayout(new BorderLayout());
		
		//create the panel objects mentioned above
		dealerPanel = new DealerHandPanel(dealer);


		
		
		//exit on close
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		
		
		
		
		//display the window
		setVisible(true);
	}
	
	
public void addbuttons(ButtonPanel panel){
		add(panel, BorderLayout.SOUTH);
	}



//refresh the game frame when called
public void Refresh(){
	SwingUtilities.updateComponentTreeUI(this);
}




}