import javax.swing.*;

import java.awt.*;

/*This class is being created by Eric.  It is to try and create a game window.
This particular class will be the Player Hand panel
This panel will contain a titled border, JLabels with the card images on them(not yet implemented), and a JLabel saying how much the hand is currently worth
this panel will be situated in the west region
*/

public class PlayerHandPanel extends JPanel
{
	//declare a JLabel intended to hold the value of the cards
	private JLabel handValue;
	//status of win or loss
	public JLabel gamestatus;
	//cardPanel to hold the imageIcons of the cards in the hand
	private CardIconPanel cardPanel;
	private PlayerHand temp;
	private int value = 0;
	
	//int varibale to be updated

	
	//constructor
	public PlayerHandPanel(PlayerHand h)
	{
		temp = h;
		cardPanel = new CardIconPanel(temp);
		//create a CardIconPanel
		setLayout(new BorderLayout());
		//create a titled border
		setBorder(BorderFactory.createTitledBorder("Player Hand"));
		//create the JLabel declared before the constructor
		handValue = new JLabel("Value: "+temp.getHandValue());
		//add the CardIconPanel to the north region of this panel
		add(cardPanel, BorderLayout.NORTH);
		//add the JLabel to the Panel
		add(handValue, BorderLayout.SOUTH);
		
		
		
	}
	//update the values on button presses
	public void updateCardDisplayPlayer(PlayerHand h){
		//if thevalue is greater than 21 tell the user they have lost
		handValue.setText("Value: "+h.getHandValue());
		this.revalidate();
		cardPanel.updateCardPanel(h);
		cardPanel.revalidate();
		this.revalidate();
	}
	

	

	
	
	
	
}