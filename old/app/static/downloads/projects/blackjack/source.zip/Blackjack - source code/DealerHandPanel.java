import javax.swing.*;
import java.awt.*;

/*This class is being created by Eric.  It is to try and create a game window.
This particular class will be the Dealer Hand panel.
This panel will contain a titled border, JLabels with the card images on them(not yet implemented), and a JLabel saying how much the hand is currently worth
This panel will be situated in the east region
*/

public class DealerHandPanel extends JPanel
{
	//declare a JLabel intended to hold the value of the cards
	private JLabel handValue;
	private CardIconPanel cardPanel;
	private PlayerHand temp;
	
	//constructor
	public DealerHandPanel(PlayerHand h)
	{
		temp = h;
		//create the CardIconPanel declared before the constructor
		cardPanel=new CardIconPanel(temp);
		//create the JLabel declared before the constructor
		handValue = new JLabel("Value: "+temp.getHandValue());
		setLayout(new BorderLayout());//might be better for adding the card icons later if a gridlayout was used instead, or if 2 panels were included in this panel.
		//create a titled border
		setBorder(BorderFactory.createTitledBorder("Dealer Hand"));
		//add the cardPanel
		add(cardPanel, BorderLayout.NORTH);
		//add the JLabel to the Panel
		add(handValue, BorderLayout.SOUTH);//make it display on the bottom of the panel
	}
	
	//update the values on button presses
	public void updateCardDisplayDealer(PlayerHand h){
		//if thevalue is greater than 21 tell the user they have lost
		handValue.setText("Value: "+h.getHandValue());
		this.revalidate();
		
		cardPanel.updateCardPanel(h);
		
		cardPanel.revalidate();
		this.revalidate();
	}
	
	//hide and show the dealer score
	public void hideValue(){
		handValue.setVisible(false);
	}
	
	
	public void showValue(){
		handValue.setVisible(true);
	}
	
	
	
	
	
}