import javax.swing.*;//needed for Swing classes
import java.awt.*;//needed for GridLayout classes
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/*
This class describes the GUI which displays 
statistics (loaded and saved to a file)
related to how well the player has done 
in past games. It is inteded to be shown by pressing a
"Show Statistics" button on the main GUI.

Note: a PlayerRecord object must be created (and maintained) by the main class, and passed into this GUI as a constructor. 
		Also, the main class must call the PlayerRecord writeDataToFile() method to actually save any new data
*/

public class StatisticsGUI extends JFrame
{
	private final int WINDOW_WIDTH = 250;//this field defines the width in pixels of the game window
	private final int WINDOW_HEIGHT = 200;//this field defines the height in pixels of the game window
	private final int LABEL_DIST = 20; //The distance the labels should be vertically seperated
			
	//JLabels to display data
	private JLabel label_wins;
	private JLabel label_loses;
	private JLabel label_standoffs;
	private JLabel label_totalGames;
	private JLabel label_blackjacks;
	public PlayerRecord record1;

	//constructor
	public StatisticsGUI(PlayerRecord record)
	{
		//set the title bar text
		setTitle("Player Statistics");
		
		this.record1 = record; //Make a copy of original to be cleared below (clears orginal too).
	
		//set the size of the window
		setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
		
		//add a border layout manager
		setLayout(new GridLayout(6, 1));
		
		//Intialize labels
		label_wins = new JLabel("Wins: " + record.getWins());
		label_loses = new JLabel("Loses: " + record.getLoses());
		label_standoffs = new JLabel("Standoffs: " + record.getStandoffs());
		label_totalGames = new JLabel("Total games: " + record.getTotalGames());
		label_blackjacks = new JLabel("Blackjacks: " + record.getBlackjacks());
		final JButton clear = new JButton("Clear Statistics");
		
		//Add labels
		this.add(label_wins);
		this.add(label_loses);
		this.add(label_standoffs);
		this.add(label_totalGames);
		this.add(label_blackjacks);
		this.add(clear); //Add clear button.

		//Listens for the clear button to be pressed.
		clear.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e) 
				{
				record1.clear(); //Clear statistics
				record1.closeGUI(); //Close GUI
				record1.displayGUI(); //Reopen GUI
				}
			}
		);
			
	}
	
	public void showWindow()
	{
		setVisible(true);
	}
	
	//Updates labels 
	public void updateLabels(PlayerRecord record)
	{ 
		label_wins = new JLabel("Wins: " + record.getWins());
		label_loses = new JLabel("Loses: " + record.getLoses());
		label_standoffs = new JLabel("Standoffs: " + record.getStandoffs());
		label_totalGames = new JLabel("Total games: " + record.getTotalGames());
		label_blackjacks = new JLabel("Blackjacks: " + record.getBlackjacks());
		System.out.println("Labels updated. Wins = " + record.getWins());
	}
	
	
}