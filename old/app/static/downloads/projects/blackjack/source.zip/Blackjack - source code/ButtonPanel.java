import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.*;

import javax.swing.*;

/*This class is being created by Eric.  It is to try and create a game window.
This particular class will be the Dealer Hand panel.
This panel will contain 2 JButtons - 1 to draw another card, 1 to hold.
This panel will be situated in the south region.
*/

public class  ButtonPanel extends JPanel
{
	//declare the two JButtons - draw and hold
	

	
	
	//constructor
	public ButtonPanel()
	{
		setLayout(new GridLayout(2,1));
	}
	
	
	
	

}