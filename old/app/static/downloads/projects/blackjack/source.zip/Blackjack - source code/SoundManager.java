//This class loads and replays sound effects for winning, lossing, drawing, and shuffling

import java.applet.*; //Import the AudioClip class (needed to play sounds)
import java.net.*;

public class SoundManager extends Applet
{
	//Attributes
	private AudioClip sound_win, sound_lose, sound_draw, sound_shuffle, sound_push; //audio clips for each sound effect
	private boolean mute; //is sound muted?
	
	//Constructor
	public SoundManager()
	{
		mute = false;
		
		try //Try to load all sound files
		{
			sound_win = Applet.newAudioClip(new URL("file:sounds/win.wav"));
			sound_lose = Applet.newAudioClip(new URL("file:sounds/lose.wav"));
			sound_draw = Applet.newAudioClip(new URL("file:sounds/draw.wav"));
			sound_shuffle = Applet.newAudioClip(new URL("file:sounds/shuffle.wav"));
			sound_push = Applet.newAudioClip(new URL("file:sounds/push.wav"));
		}
		catch (MalformedURLException ex) //Catch exception if files not found
		{
			System.out.println("Error: some of the sounds could not be loaded.");
		}
	}

	

	//Plays the win sound effect
	public void playWinSound()
	{
		if( !mute ) //Play sound if the game isn't muted
			sound_win.play(); 
		
	}
	
	//Plays the lose sound effect
	public void playLoseSound()
	{
		if( !mute ) //Play sound if the game isn't muted
			sound_lose.play();
	}
	
	//Plays the draw sound effect
	public void playDrawSound()
	{
		if( !mute ) //Play sound if the game isn't muted
		{
			stopAllSounds();
			sound_draw.play();
		}
		pause(.3); //Pause program .3 seconds.
	}
	
	//Plays the push sound effect
	public void playPushSound()
	{
		if( !mute ) //Play sound if the game isn't muted
		{
			stopAllSounds();
			sound_push.play();
			pause(.3); //Pause program .3 seconds.
		}
	}
	
	//Plays the shuffle sound effect
	public void playShuffleSound()
	{
		if( !mute ) //Play sound if the game isn't muted
		{
			stopAllSounds();
			sound_shuffle.play();
			pause(1); //Pause program 1 second.
		}
	}
	
	//Stops any audio clips that may be playing
	public void stopAllSounds()
	{
		sound_win.stop();
		sound_lose.stop();
		sound_draw.stop();
		sound_shuffle.stop();
	}	
	
	public void toggleMute()
	{
		mute = !mute; //toggle if mute is on
		
		if(mute) //If mute has been turned on immediately stop all sounds playing
			stopAllSounds();
	}
	
	
	//Pauses the program for a number of milliseconds.
	public void pause(double i){ //Note that the input is in seconds.
		
		int k = (int)i*1000; //converts parameter to milliseconds.
		
		try {
		Thread.sleep(k); 
		} catch(InterruptedException e) {
		} 
	}
		
}