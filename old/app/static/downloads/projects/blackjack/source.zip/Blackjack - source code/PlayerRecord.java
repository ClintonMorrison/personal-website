import java.io.*;
import java.util.Scanner;
import java.util.InputMismatchException; 

//This class maintains a record of several statistics about how the player has performed in past games
//The class contains methods to store and read this data from a file
//
//Note - additional statistics/records can also be easily added to this file, but the read and write methods would need to be updated

public class PlayerRecord
{
	//Attributes
	private int wins; //Number of games the player has won in total
	private int loses; //Number of games the player has lost in total
	private int standoffs; //Number of games the player has tied
	private int totalGames; //Total games played by the player
	private int blackjacks; //Total number of black jacks the player has obtained
	
	private StatisticsGUI gui; //The GUI which displays the player statistics
	private BlackjackGUI mainGUI;
	
	//No args constructor
	public PlayerRecord()
	{
		//Set all values to 0
		wins = 0;
		loses = 0;
		standoffs = 0;
		totalGames = 0;
		blackjacks = 0;
		gui = new StatisticsGUI(this);
		gui.setLocationRelativeTo(mainGUI);
	}
	
	//Constructor to directly load data from file
	public PlayerRecord(String filename)
	{
		this.mainGUI = mainGUI;
		readDataFromFile(filename); //Read data from give file
		gui = new StatisticsGUI(this);
	}
	
	//Loads data from file
	public void readDataFromFile(String filename)
	{
		try
		{
			File file = new File(filename); 
			Scanner inputFile = new Scanner(file); //Open file
			
			wins = inputFile.nextInt(); //Read number of wins (the first integer in file)
			loses = inputFile.nextInt(); //Read number of loses (the second integer in file)
			standoffs = inputFile.nextInt(); //Read number of standoffs
			totalGames = wins + loses + standoffs; //Calculate number of games (starting but not finishing a game is not considered a full game)
			blackjacks = inputFile.nextInt(); //Read number of blackjacks (third integer in file)
		
			inputFile.close(); //Close the file
		}
		catch(IOException | InputMismatchException ex) //If the file could not be opened, or integers cannot be read (catch both exceptions)
		{
			//print error message.
			System.out.println("Warning: no file found, or data is invalid."); 
		}
		
	}
	
	//Writes data to file
	public void writeDataToFile(String filename)
	{
		try
		{
			PrintWriter outputFile = new PrintWriter(filename);
			
			//Write output to the file in the following way:
			outputFile.println(wins); //Line1: wins
			outputFile.println(loses); //Line2: loses
			outputFile.println(standoffs); //Line3: standoffs
			outputFile.println(blackjacks); //Line3: blackjacks	(Note: total games is not written to file since it can be calculated from wins, stnadoffs and loses)
			
			outputFile.close();
		}
		catch (IOException ex)
		{
			System.out.println("Error. File could not be written. Data not saved.");
		}
	}
	
	//Shows the GUI
	public void displayGUI(BlackjackGUI mainGUI)
	{
		if(gui.isVisible() == false)
		{
			this.mainGUI = mainGUI;
			gui = new StatisticsGUI(this); //Recreate window with up to date labels
			gui.showWindow(); //Show the window
			gui.setLocationRelativeTo(mainGUI);
		}
	}
	
	//Shows the GUI
	public void displayGUI()
	{
		if(gui.isVisible() == false)
		{
			gui = new StatisticsGUI(this); //Recreate window with up to date labels
			gui.showWindow(); //Show the window
			gui.setLocationRelativeTo(mainGUI);
		}
	}

	
	//Closes the GUI
	public void closeGUI()
	{
		gui.setVisible(false); //hide the window
		gui.dispose(); //and free the resources
	}
	
	//Destroys and recreates GUI, with updated labels
	public void updateGUI()
	{
		if(gui.isVisible() == true) //If the user had the GUI open
		{
			closeGUI(); //Close it
			displayGUI(mainGUI); //Display it again
		}
	}
	
	
	//Increments the player's wins by 1 (also increments totalGames)
	public void incrementWins()
	{
		wins++;
		totalGames++;
		updateGUI();
	}
	
	//Increments the player's wins by 1 (also increments totalGames)
	public void incrementLoses()
	{
		loses++;
		totalGames++;
		updateGUI();
	}
	
	//Increments the player's wins by 1 (also increments totalGames)
	public void incrementStandoffs()
	{
		standoffs++;
		totalGames++;
		updateGUI();
	}
	
	//Note - There is no method to increment totalGames because it is automatically incremented by incrementing wins, stnadoffs, or loses
	
	//Increments number of blackjacks obtains by the player
	public void incrementBlackjacks()
	{
		blackjacks++;
		updateGUI();
	}
	
	
	//Get number of times player won
	public int getWins()
	{
		return wins;
	}
	
	//Get the number times the player lost
	public int getLoses()
	{
		return loses;
	}
	
		//Get the number times the player tied
	public int getStandoffs()
	{
		return standoffs;
	}
	
	//Get the number of black jacks the user has gotten
	public int getBlackjacks()
	{
		return blackjacks;
	}
	
	//Get the total number of games the played participated in 
	public int getTotalGames()
	{
		return totalGames;
	}
	
	
	//Set number of wins
	public void setWins(int wins)
	{
		this.wins = wins;
	}
	
	//Set number of blackjacks
	public void setBlackjacks(int blackjacks)
	{
		this.blackjacks = blackjacks;
	}
	
	//Set number of loses
	public void setLoses(int loses)
	{
		this.loses = loses;
	}
	
	//Set number of standoffs
	public void setStandoffs(int standoffs)
	{
		this.standoffs = standoffs;
	}
	
	//Returns string version of the data
	public String toString()
	{
		return "[Wins:"+wins + "  Loses:"+loses + "  Standoffs:"+standoffs +  "  Blackjacks:"+blackjacks+"]";
	}
	
	//This method clears the statistics 
	public void clear(){
		this.wins = 0;
		this.loses = 0;
		this.standoffs = 0;
		this.totalGames = 0;
		this.blackjacks = 0;
	}
}