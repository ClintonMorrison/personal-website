import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;


public class RPGGame extends AppletGame
{
	//Called when the game starts (loading code here)
	public void gameStart() {
		// TODO Auto-generated method stub
		
	}

	//Updates the state of the game
	public void gameUpdate(long millisTaken, Vector mousePosition) 
	{
		// TODO Auto-generated method stub
		
	}

	//Destroys the game when applet is closed
	public void gameStop() {
		// TODO Auto-generated method stub
		
	}

	//Renders game to be drawn to applet
	public void drawGame(Graphics g) 
	{	
		g.setColor(Color.GREEN);
		g.drawString("Hello World!", 100, 100);
	}
	
	
	
	
	
	
	
	
	
	
	
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void gameUpdate(long millisTaken, UserInput currentUserInput) {
		// TODO Auto-generated method stub
		
	}

}

