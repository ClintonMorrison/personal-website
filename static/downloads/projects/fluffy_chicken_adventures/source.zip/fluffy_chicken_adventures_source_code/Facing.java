/*
 * Author: Clinton Morrison
 * Date: May 16, 2013
 */


/*
 * This ennumeration is used to keep track of which way
 * objects in the game are facing
 * 
 */
public enum Facing {
	
	RIGHT, LEFT
	
}
