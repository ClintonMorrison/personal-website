﻿namespace Password_Manager
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage_list = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.listBox_sites = new System.Windows.Forms.ListBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button_delete = new System.Windows.Forms.Button();
            this.button_editInformation = new System.Windows.Forms.Button();
            this.textBox_outputEmail = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox_outputDescription = new System.Windows.Forms.TextBox();
            this.textBox_outputOther = new System.Windows.Forms.TextBox();
            this.textBox_outputPassword = new System.Windows.Forms.TextBox();
            this.textBox_outputUsername = new System.Windows.Forms.TextBox();
            this.textBox_outputURL = new System.Windows.Forms.TextBox();
            this.textBox_outputName = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label_warning_selectWebsite = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.tabPage_addPassword = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.textBox_inputEmail = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.button_submitInformation = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox_inputDescription = new System.Windows.Forms.TextBox();
            this.textBox_inputOther = new System.Windows.Forms.TextBox();
            this.textBox_inputPassword = new System.Windows.Forms.TextBox();
            this.textBox_inputUsername = new System.Windows.Forms.TextBox();
            this.textBox_inputURL = new System.Windows.Forms.TextBox();
            this.textBox_inputName = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPage_about = new System.Windows.Forms.TabPage();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage_list.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage_addPassword.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tabPage_about.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage_list);
            this.tabControl1.Controls.Add(this.tabPage_addPassword);
            this.tabControl1.Controls.Add(this.tabPage_about);
            this.tabControl1.Location = new System.Drawing.Point(13, 13);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(737, 445);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage_list
            // 
            this.tabPage_list.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage_list.Controls.Add(this.groupBox3);
            this.tabPage_list.Controls.Add(this.groupBox2);
            this.tabPage_list.Controls.Add(this.groupBox1);
            this.tabPage_list.Location = new System.Drawing.Point(4, 22);
            this.tabPage_list.Name = "tabPage_list";
            this.tabPage_list.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_list.Size = new System.Drawing.Size(729, 419);
            this.tabPage_list.TabIndex = 0;
            this.tabPage_list.Text = "Passwords";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label23);
            this.groupBox3.Controls.Add(this.label22);
            this.groupBox3.Controls.Add(this.listBox_sites);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(12, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(176, 301);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Websites and Programs";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(3, 32);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(146, 13);
            this.label23.TabIndex = 4;
            this.label23.Text = "the list click \"Add Password\".";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(0, 19);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(154, 13);
            this.label22.TabIndex = 3;
            this.label22.Text = "To add a website or program to";
            // 
            // listBox_sites
            // 
            this.listBox_sites.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox_sites.FormattingEnabled = true;
            this.listBox_sites.Location = new System.Drawing.Point(6, 57);
            this.listBox_sites.Name = "listBox_sites";
            this.listBox_sites.ScrollAlwaysVisible = true;
            this.listBox_sites.Size = new System.Drawing.Size(158, 238);
            this.listBox_sites.TabIndex = 0;
            this.listBox_sites.SelectedIndexChanged += new System.EventHandler(this.listBox_sites_SelectedIndexChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button_delete);
            this.groupBox2.Controls.Add(this.button_editInformation);
            this.groupBox2.Controls.Add(this.textBox_outputEmail);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.textBox_outputDescription);
            this.groupBox2.Controls.Add(this.textBox_outputOther);
            this.groupBox2.Controls.Add(this.textBox_outputPassword);
            this.groupBox2.Controls.Add(this.textBox_outputUsername);
            this.groupBox2.Controls.Add(this.textBox_outputURL);
            this.groupBox2.Controls.Add(this.textBox_outputName);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label_warning_selectWebsite);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(194, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(526, 407);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Information";
            // 
            // button_delete
            // 
            this.button_delete.Enabled = false;
            this.button_delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_delete.Location = new System.Drawing.Point(445, 374);
            this.button_delete.Name = "button_delete";
            this.button_delete.Size = new System.Drawing.Size(75, 23);
            this.button_delete.TabIndex = 8;
            this.button_delete.Text = "Delete";
            this.button_delete.UseVisualStyleBackColor = true;
            this.button_delete.Click += new System.EventHandler(this.button1_Click);
            // 
            // button_editInformation
            // 
            this.button_editInformation.Enabled = false;
            this.button_editInformation.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_editInformation.Location = new System.Drawing.Point(364, 374);
            this.button_editInformation.Name = "button_editInformation";
            this.button_editInformation.Size = new System.Drawing.Size(75, 23);
            this.button_editInformation.TabIndex = 7;
            this.button_editInformation.Text = "Edit";
            this.button_editInformation.UseVisualStyleBackColor = true;
            this.button_editInformation.MouseClick += new System.Windows.Forms.MouseEventHandler(this.button_editInformation_MouseClick);
            // 
            // textBox_outputEmail
            // 
            this.textBox_outputEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_outputEmail.Location = new System.Drawing.Point(160, 157);
            this.textBox_outputEmail.Name = "textBox_outputEmail";
            this.textBox_outputEmail.ReadOnly = true;
            this.textBox_outputEmail.Size = new System.Drawing.Size(360, 20);
            this.textBox_outputEmail.TabIndex = 4;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(13, 160);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(35, 13);
            this.label12.TabIndex = 28;
            this.label12.Text = "Email:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(13, 186);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(63, 13);
            this.label13.TabIndex = 27;
            this.label13.Text = "Description:";
            // 
            // textBox_outputDescription
            // 
            this.textBox_outputDescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_outputDescription.Location = new System.Drawing.Point(160, 183);
            this.textBox_outputDescription.Multiline = true;
            this.textBox_outputDescription.Name = "textBox_outputDescription";
            this.textBox_outputDescription.ReadOnly = true;
            this.textBox_outputDescription.Size = new System.Drawing.Size(360, 74);
            this.textBox_outputDescription.TabIndex = 5;
            // 
            // textBox_outputOther
            // 
            this.textBox_outputOther.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_outputOther.Location = new System.Drawing.Point(160, 262);
            this.textBox_outputOther.Multiline = true;
            this.textBox_outputOther.Name = "textBox_outputOther";
            this.textBox_outputOther.ReadOnly = true;
            this.textBox_outputOther.Size = new System.Drawing.Size(360, 74);
            this.textBox_outputOther.TabIndex = 6;
            // 
            // textBox_outputPassword
            // 
            this.textBox_outputPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_outputPassword.Location = new System.Drawing.Point(160, 131);
            this.textBox_outputPassword.Name = "textBox_outputPassword";
            this.textBox_outputPassword.ReadOnly = true;
            this.textBox_outputPassword.Size = new System.Drawing.Size(360, 20);
            this.textBox_outputPassword.TabIndex = 3;
            // 
            // textBox_outputUsername
            // 
            this.textBox_outputUsername.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_outputUsername.Location = new System.Drawing.Point(160, 105);
            this.textBox_outputUsername.Name = "textBox_outputUsername";
            this.textBox_outputUsername.ReadOnly = true;
            this.textBox_outputUsername.Size = new System.Drawing.Size(360, 20);
            this.textBox_outputUsername.TabIndex = 2;
            // 
            // textBox_outputURL
            // 
            this.textBox_outputURL.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_outputURL.Location = new System.Drawing.Point(160, 79);
            this.textBox_outputURL.Name = "textBox_outputURL";
            this.textBox_outputURL.ReadOnly = true;
            this.textBox_outputURL.Size = new System.Drawing.Size(360, 20);
            this.textBox_outputURL.TabIndex = 1;
            // 
            // textBox_outputName
            // 
            this.textBox_outputName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_outputName.Location = new System.Drawing.Point(160, 53);
            this.textBox_outputName.Name = "textBox_outputName";
            this.textBox_outputName.ReadOnly = true;
            this.textBox_outputName.Size = new System.Drawing.Size(360, 20);
            this.textBox_outputName.TabIndex = 0;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(13, 265);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(90, 13);
            this.label14.TabIndex = 20;
            this.label14.Text = "Other information:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(13, 134);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(56, 13);
            this.label15.TabIndex = 19;
            this.label15.Text = "Password:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(13, 108);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(58, 13);
            this.label16.TabIndex = 18;
            this.label16.Text = "Username:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(13, 82);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(74, 13);
            this.label17.TabIndex = 17;
            this.label17.Text = "Website URL:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(13, 56);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(124, 13);
            this.label18.TabIndex = 16;
            this.label18.Text = "Website/Program Name:";
            // 
            // label_warning_selectWebsite
            // 
            this.label_warning_selectWebsite.AutoSize = true;
            this.label_warning_selectWebsite.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_warning_selectWebsite.Location = new System.Drawing.Point(7, 19);
            this.label_warning_selectWebsite.Name = "label_warning_selectWebsite";
            this.label_warning_selectWebsite.Size = new System.Drawing.Size(359, 13);
            this.label_warning_selectWebsite.TabIndex = 0;
            this.label_warning_selectWebsite.Text = "Select an item from the list to see information about the website or program.";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(6, 313);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(182, 100);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Search";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(9, 42);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(56, 13);
            this.label19.TabIndex = 3;
            this.label19.Text = "bar below.";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(9, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(161, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "in a related phrase in the search ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(163, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "To search for a specific item type";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(9, 70);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(153, 20);
            this.textBox1.TabIndex = 0;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // tabPage_addPassword
            // 
            this.tabPage_addPassword.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage_addPassword.Controls.Add(this.groupBox4);
            this.tabPage_addPassword.Location = new System.Drawing.Point(4, 22);
            this.tabPage_addPassword.Name = "tabPage_addPassword";
            this.tabPage_addPassword.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_addPassword.Size = new System.Drawing.Size(729, 419);
            this.tabPage_addPassword.TabIndex = 1;
            this.tabPage_addPassword.Text = "Add Password";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.textBox_inputEmail);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Controls.Add(this.button_submitInformation);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Controls.Add(this.textBox_inputDescription);
            this.groupBox4.Controls.Add(this.textBox_inputOther);
            this.groupBox4.Controls.Add(this.textBox_inputPassword);
            this.groupBox4.Controls.Add(this.textBox_inputUsername);
            this.groupBox4.Controls.Add(this.textBox_inputURL);
            this.groupBox4.Controls.Add(this.textBox_inputName);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(58, 6);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(614, 407);
            this.groupBox4.TabIndex = 0;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Add Password";
            // 
            // textBox_inputEmail
            // 
            this.textBox_inputEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_inputEmail.Location = new System.Drawing.Point(157, 159);
            this.textBox_inputEmail.Name = "textBox_inputEmail";
            this.textBox_inputEmail.Size = new System.Drawing.Size(360, 20);
            this.textBox_inputEmail.TabIndex = 4;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(10, 162);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(35, 13);
            this.label11.TabIndex = 14;
            this.label11.Text = "Email:";
            // 
            // button_submitInformation
            // 
            this.button_submitInformation.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_submitInformation.Location = new System.Drawing.Point(533, 378);
            this.button_submitInformation.Name = "button_submitInformation";
            this.button_submitInformation.Size = new System.Drawing.Size(75, 23);
            this.button_submitInformation.TabIndex = 7;
            this.button_submitInformation.Text = "Submit";
            this.button_submitInformation.UseVisualStyleBackColor = true;
            this.button_submitInformation.Click += new System.EventHandler(this.button_submitInformation_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(10, 188);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(63, 13);
            this.label10.TabIndex = 12;
            this.label10.Text = "Description:";
            // 
            // textBox_inputDescription
            // 
            this.textBox_inputDescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_inputDescription.Location = new System.Drawing.Point(157, 185);
            this.textBox_inputDescription.Multiline = true;
            this.textBox_inputDescription.Name = "textBox_inputDescription";
            this.textBox_inputDescription.Size = new System.Drawing.Size(360, 74);
            this.textBox_inputDescription.TabIndex = 5;
            // 
            // textBox_inputOther
            // 
            this.textBox_inputOther.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_inputOther.Location = new System.Drawing.Point(157, 265);
            this.textBox_inputOther.Multiline = true;
            this.textBox_inputOther.Name = "textBox_inputOther";
            this.textBox_inputOther.Size = new System.Drawing.Size(360, 74);
            this.textBox_inputOther.TabIndex = 6;
            // 
            // textBox_inputPassword
            // 
            this.textBox_inputPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_inputPassword.Location = new System.Drawing.Point(157, 133);
            this.textBox_inputPassword.Name = "textBox_inputPassword";
            this.textBox_inputPassword.Size = new System.Drawing.Size(360, 20);
            this.textBox_inputPassword.TabIndex = 3;
            // 
            // textBox_inputUsername
            // 
            this.textBox_inputUsername.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_inputUsername.Location = new System.Drawing.Point(157, 107);
            this.textBox_inputUsername.Name = "textBox_inputUsername";
            this.textBox_inputUsername.Size = new System.Drawing.Size(360, 20);
            this.textBox_inputUsername.TabIndex = 2;
            // 
            // textBox_inputURL
            // 
            this.textBox_inputURL.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_inputURL.Location = new System.Drawing.Point(157, 81);
            this.textBox_inputURL.Name = "textBox_inputURL";
            this.textBox_inputURL.Size = new System.Drawing.Size(360, 20);
            this.textBox_inputURL.TabIndex = 1;
            // 
            // textBox_inputName
            // 
            this.textBox_inputName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_inputName.Location = new System.Drawing.Point(157, 55);
            this.textBox_inputName.Name = "textBox_inputName";
            this.textBox_inputName.Size = new System.Drawing.Size(360, 20);
            this.textBox_inputName.TabIndex = 0;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(10, 268);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(90, 13);
            this.label9.TabIndex = 5;
            this.label9.Text = "Other information:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(10, 136);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(56, 13);
            this.label8.TabIndex = 4;
            this.label8.Text = "Password:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(10, 110);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 13);
            this.label7.TabIndex = 3;
            this.label7.Text = "Username:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(10, 84);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "Website URL:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(10, 58);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(124, 13);
            this.label6.TabIndex = 1;
            this.label6.Text = "Website/Program Name:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(7, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(345, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Fill out the below fields and press \"Submit\" to add a password to the list.";
            // 
            // tabPage_about
            // 
            this.tabPage_about.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage_about.Controls.Add(this.label21);
            this.tabPage_about.Controls.Add(this.label20);
            this.tabPage_about.Controls.Add(this.label1);
            this.tabPage_about.Location = new System.Drawing.Point(4, 22);
            this.tabPage_about.Name = "tabPage_about";
            this.tabPage_about.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_about.Size = new System.Drawing.Size(729, 419);
            this.tabPage_about.TabIndex = 2;
            this.tabPage_about.Text = "About";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(6, 15);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(63, 13);
            this.label21.TabIndex = 2;
            this.label21.Text = "Version: 1.0";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(6, 41);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(409, 13);
            this.label20.TabIndex = 1;
            this.label20.Text = "This software is intended to provide a convient way for users to store their pass" +
    "words.";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 65);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(197, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Software developed by Clinton Morrison.";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(759, 468);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = " Password Manager";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.tabControl1.ResumeLayout(false);
            this.tabPage_list.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage_addPassword.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.tabPage_about.ResumeLayout(false);
            this.tabPage_about.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage_list;
        private System.Windows.Forms.TabPage tabPage_addPassword;
        private System.Windows.Forms.TabPage tabPage_about;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ListBox listBox_sites;
        private System.Windows.Forms.Label label_warning_selectWebsite;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox textBox_inputEmail;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button_submitInformation;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox_inputDescription;
        private System.Windows.Forms.TextBox textBox_inputOther;
        private System.Windows.Forms.TextBox textBox_inputPassword;
        private System.Windows.Forms.TextBox textBox_inputUsername;
        private System.Windows.Forms.TextBox textBox_inputURL;
        private System.Windows.Forms.TextBox textBox_inputName;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_outputEmail;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox_outputDescription;
        private System.Windows.Forms.TextBox textBox_outputOther;
        private System.Windows.Forms.TextBox textBox_outputPassword;
        private System.Windows.Forms.TextBox textBox_outputUsername;
        private System.Windows.Forms.TextBox textBox_outputURL;
        private System.Windows.Forms.TextBox textBox_outputName;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button button_editInformation;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button button_delete;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
    }
}

