﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace Password_Manager
{
    //This class stores the set of all information saved by user for all websites/programs
    [Serializable]
    class InformationManager
    {
        //Attributes
        private LinkedList<Information> allInformation;
        private List<String> names;
        private String search_str = ""; //Search string, entered by user, determines what names are on list (only names with the same first characters)

        //Constructor
        public InformationManager()
        {
            allInformation = new LinkedList<Information>();
            names = new List<String>();
        }

        //Adds a set of information to records
        public void addInformation(Information info)
        {
            //Make sure name doesn't already exist
            if (names.Contains(info.getName()))
            {
                MessageBox.Show("Information has already been entered for the program/site \"" + info.getName() + "\". Please change the name or remove the other entry.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                return;
            }

            allInformation.AddLast(info);
            names.Add(info.getName());

            sortNameList();
        }

        //Removes a set of information from records
        public void removeInformation(String name)
        {
            Information info = getInformation(name);
            allInformation.Remove(info);
            names.Remove(info.getName());

            sortNameList();
        }

        //Writes serialized version of this object to file
        public void writeAllInformationToFile()
        {
           
        }

        //Gets list of names
        public List<String> getNameList()
        {
            List<String> namesToShow = new List<String>(); //Effected by alphabetical string entered by user 

            if (search_str.Equals("")) //If the user is not searching, return all names
                return names;

            for (int i = 0; i < names.Count; i++) //If the user is searching, only return names 
            {
                if(names.ElementAt<String>(i).Length >= search_str.Length)
                    if (names.ElementAt<String>(i).Substring(0, search_str.Length).ToLower().Equals(search_str.ToLower())) //Check if name has same first few characters as search string (entered by user)
                        namesToShow.Add(names.ElementAt<String>(i)); //Only show names where this is true
            }

            return namesToShow;
        }

        //Gets information at specified index
        public Information getInformation(String name)
        {
            if (allInformation.Count > 0)
            {
                LinkedListNode<Information> curr = allInformation.First;

                while (curr != null)
                {
                    if (curr.Value.getName().Equals(name))
                        return curr.Value;

                    curr = curr.Next;
                }
            }

            return null; //Return null if entry couldn't be found or if list empty
        }

        //Sorts the list of names, and sorts information based on that
        public void sortNameList()
        {
            names.Sort(); //Sort list of names   
        }

        //Sets the string to search for (excludes names from name list that don't match search string)
        public void setSearchString(String search)
        {
            search_str = search;
        }
    }
}
