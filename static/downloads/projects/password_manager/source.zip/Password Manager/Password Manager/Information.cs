﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Password_Manager
{
    //This class stores all of the information entered by the user about a given website/program.
    [Serializable]
    class Information
    {
        //Attributes
        private String name; //Name of site/program
        private String URL; //URL of website (if applicable)
        private String username; //Username of user
        private String password; //Password corresponding to username
        private String email; //User email related to program/site
        private String description; //A description of the website/program for the user
        private String otherInfo; //Other information enter by user

        //Constructor
        public Information(String name, String URL, String username, String password, String email, String description, String otherInfo)
        {
            //Assign all varaibles a value
            this.name = name;
            this.URL = URL;
            this.username = username;
            this.password = password;
            this.email = email;
            this.description = description;
            this.otherInfo = otherInfo;
        }

        //Get methods
        public String getName()
        {
            return name;
        }

        public String getURL()
        {
            return URL;
        }

        public String getUsername()
        {
            return username;
        }

        public String getPassword()
        {
            return password;
        }

        public String getEmail()
        {
            return email;
        }

        public String getDescription()
        {
            return description;
        }

        public String getOtherInfo()
        {
            return otherInfo;
        }

        //Set methods
        public void setName(String name)
        {
            this.name = name;
        }

        public void setURL(String URL)
        {
            this.URL = URL;
        }

        public void setUsername(String username)
        {
            this.username = username;
        }

        public void setPassword(String password)
        {
            this.password = password;
        }

        public void setEmail(String email)
        {
            this.email = email;
        }

        public void setDecription(String description)
        {
            this.description = description;
        }

        public void setOtherInfo(String otherInfo)
        {
            this.otherInfo = otherInfo;
        }

        //Copies this information
        public Information copy()
        {
            return new Information(name, URL, username, password, email, description, otherInfo);
        }

    }
}
