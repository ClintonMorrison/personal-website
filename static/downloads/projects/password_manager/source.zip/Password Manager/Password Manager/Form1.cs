﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace Password_Manager
{
    public partial class Form1 : Form
    {
        InformationManager informationRecords; //All of the information entered by user
        Boolean editOn; //Is the information section in edit mode?
        String informationBeingEdited = ""; //What information is being edited?

        public Form1()
        {
            InitializeComponent();
            editOn = false;

            //Try to load information data from file
            try
            {
                //Deserialize the data
                IFormatter formatter = new BinaryFormatter();
                Stream stream = new FileStream("password_data.bin", FileMode.Open, FileAccess.Read, FileShare.Read);
                
                //Create new object and close file
                informationRecords = (InformationManager)formatter.Deserialize(stream);
                stream.Close();

                //Update list to show passwords loaded
                updateList();
            }
            //If the file could not be found
            catch (FileNotFoundException e)
            {
                //Show welcome dialog, intialize empty information manager
                MessageBox.Show("It looks like this is the first time you have launched Password Manager! Hopefully you find this software a convienent and useful way to store your passwords.", "Welcome", MessageBoxButtons.OK, MessageBoxIcon.None, MessageBoxDefaultButton.Button1);
                informationRecords = new InformationManager();
            }

        
        }

        //If the user tries to submit a new set of information
        private void button_submitInformation_Click(object sender, EventArgs e)
        {
            //Create new information object and add it to records
            Information info = new Information(textBox_inputName.Text, textBox_inputURL.Text, textBox_inputUsername.Text, textBox_inputPassword.Text, textBox_inputEmail.Text, textBox_inputDescription.Text, textBox_inputOther.Text);
            informationRecords.addInformation(info);

            //Update list
            updateList();

            //Clear all of the input textboxs
            clearInputTextboxs();

            //Switch user's view back to main information page
            tabControl1.SelectedIndex = 0;

        }

        //Event triggered when user selects a different name from the list
        private void listBox_sites_SelectedIndexChanged(object sender, EventArgs e)
        {
        
            //Get name of information
            if (listBox_sites.SelectedValue != null) //If a valid value is selected
            {
                //Enable buttons since information is selected
                button_delete.Enabled = true;
                button_editInformation.Enabled = true;

                String name = listBox_sites.SelectedValue.ToString(); //Get name of information
                Information info = informationRecords.getInformation(name);

                //Enter new information into form
                textBox_outputName.Text = info.getName();
                textBox_outputURL.Text = info.getURL();
                textBox_outputUsername.Text = info.getUsername();
                textBox_outputPassword.Text = info.getPassword();
                textBox_outputEmail.Text = info.getEmail();
                textBox_outputDescription.Text = info.getDescription();
                textBox_outputOther.Text = info.getOtherInfo();
            }
            else //If no element is selected
            {
                clearOutputTextboxs(); //Clear the textboxs to no information is displayed

                //Disable buttons since no information is selected
                button_delete.Enabled = false;
                button_editInformation.Enabled = false;
                
            }
            
        }

        //Updates the list box
        private void updateList()
        {
            listBox_sites.DataSource = null;
            listBox_sites.DataSource = informationRecords.getNameList();
        }

        //Event triggered when user wants to enter edit mode or leave edit mode
        private void button_editInformation_MouseClick(object sender, MouseEventArgs e)
        {
            if (editOn) //The user is currently in edit mode
            {
                editOn = false; //Turn off edit mode

                //Make all textboxs read only again
                textBox_outputName.ReadOnly = true;
                textBox_outputURL.ReadOnly = true;
                textBox_outputUsername.ReadOnly = true;
                textBox_outputPassword.ReadOnly = true;
                textBox_outputEmail.ReadOnly = true;
                textBox_outputDescription.ReadOnly = true;
                textBox_outputOther.ReadOnly = true;

                //Change text on button back
                button_editInformation.Text = "Edit";

                //Remove old entry
                informationRecords.removeInformation(informationBeingEdited);

                //Create new information object and add it to records
                Information info = new Information(textBox_outputName.Text, textBox_outputURL.Text, textBox_outputUsername.Text, textBox_outputPassword.Text, textBox_outputEmail.Text, textBox_outputDescription.Text, textBox_outputOther.Text);
                informationRecords.addInformation(info);

                //Update list
                updateList();

                this.Refresh();

                //Make it so the user can change what item he has selected
                listBox_sites.SelectionMode = SelectionMode.One;

                //Set the selected index to the edited item
                listBox_sites.SelectedIndex = listBox_sites.FindString(textBox_outputName.Text);
            }
            else if (!editOn && listBox_sites.SelectedItem != null) //Otherwise if the user is currently not in edit mode
            {
                editOn = true; //Turn on edit mode

                //Make all textboxs writeable
                textBox_outputName.ReadOnly = false;
                textBox_outputURL.ReadOnly = false;
                textBox_outputUsername.ReadOnly = false;
                textBox_outputPassword.ReadOnly = false;
                textBox_outputEmail.ReadOnly = false;
                textBox_outputDescription.ReadOnly = false;
                textBox_outputOther.ReadOnly = false;

                //Change text on button back
                button_editInformation.Text = "Save Changes";

                //Note what item the user is editing
                informationBeingEdited = listBox_sites.SelectedItem.ToString(); 

                //Make it so the user cannot change what item he has selected
                listBox_sites.SelectionMode = SelectionMode.None;
            }
        }

        //Clears all of the input textboxs
        private void clearInputTextboxs()
        {
            textBox_inputDescription.Text = "";
            textBox_inputEmail.Text = "";
            textBox_inputName.Text = "";
            textBox_inputOther.Text = "";
            textBox_inputPassword.Text = "";
            textBox_inputURL.Text = "";
            textBox_inputUsername.Text = "";
        }

        //Clears all of the input textboxs
        private void clearOutputTextboxs()
        {
            textBox_outputDescription.Text = "";
            textBox_outputEmail.Text = "";
            textBox_outputName.Text = "";
            textBox_outputOther.Text = "";
            textBox_outputPassword.Text = "";
            textBox_outputURL.Text = "";
            textBox_outputUsername.Text = "";
        }

        //Triggered if user presses delete record button
        private void button1_Click(object sender, EventArgs e)
        {
            if(listBox_sites.SelectedItem != null) //If user has an item selected
            {
                //Prompt user to make sure they want to delete the information
                DialogResult result1 = MessageBox.Show("Are you sure you want to delete all of the information stored about " + listBox_sites.SelectedItem.ToString() + "?", "Confirm delete", MessageBoxButtons.YesNo);
                if (result1 == DialogResult.Yes) //If the user says yes  to deleting it
                {
                    informationRecords.removeInformation(listBox_sites.SelectedItem.ToString()); //Remove information about selected item
                    updateList(); //Update the list
                }
            }
            else
            {
                Console.WriteLine("Error! You should not be reading this because the delete button should be disabled.");
            }
        }

        //Called when the user searchs for a string within the names
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            informationRecords.setSearchString(textBox1.Text); //Set the search string to the text the user entered into the search textbox
            updateList(); //Update list so user can see change
        }

        //Called as window closing
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            //Create output stream and serialize password data into output file, which can later be loaded
            IFormatter formatter = new BinaryFormatter();
            Stream stream = new FileStream("password_data.bin", FileMode.Create, FileAccess.Write, FileShare.None);
            formatter.Serialize(stream, informationRecords);
            stream.Close();
        }

     

    }
}
